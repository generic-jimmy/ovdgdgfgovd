# BackstageInjection (Rust) — BINJv1.3

Updated injection engine. Drop-in replacement: same sources layout, same
build pipeline (`scripts/build-backstage-dll.sh` / `.bat`), same agent
contract (`RDI_*` env, `x######` loader export, file-offset reflective load).
Built artifact included: `BackstageInjection.dll`
(x86_64-pc-windows-gnu, static CRT).

## New in v1.3: env-name hash matching + blob hardening (src/obf.rs v3)

The v1.2 engine hid every literal statically, but env/config names still
materialized at runtime: each read called `GetEnvironmentVariableW(name)`,
so a single breakpoint or API hook on that export (or a stack scan during
config load) printed the whole configuration contract — `RDI_SEARCH_PATH`,
`RDI_REPLACE_PATH`, `RDI_DLL_SECTION`, `RDI_DLL_SIZE`,
`BackstageInjectionDebug`, `TEMP` — in one shot. And `obfb!` decoded any
embedded blob into one stack array: fine for strings, fatal for real
payloads (stack exhaustion, one contiguous plaintext region, no cleanup).

**Env-name hash matching (`envname!`).** Config/env names are no longer
encrypted — they are *never materialized anywhere*:

- The plaintext name exists only inside the compiler. `envname!(b"NAME")`
  compiles to a per-site `EnvTag`: two independent 64-bit hash values, both
  derived from the v2 per-site randomized mixer (per-site parameters,
  per-build seed, position-salted site key).
- At runtime the process environment block is enumerated
  (`GetEnvironmentStringsW`) and each candidate NAME is folded with the same
  chains and compared. On a double-hash match the VALUE is copied out;
  `FreeEnvironmentStringsW` releases the block. The name itself never
  appears in the image, on the stack, in registers, or at any API boundary —
  there is nothing to breakpoint, sweep or scrape.
- Preimage hardness: each fold step mixes the unit through the bijective
  per-site mixer, so an attacker holding the final h1/h2 and every constant
  in the disassembly can only work backwards by guessing units — charset^n
  per length — and every guess must satisfy BOTH chains. Guess-and-check
  dictionary verification remains theoretically possible (the honest limit,
  same class as password hashing); per-site + per-build randomization keeps
  precomputed tables useless.
- Match is exact and case-sensitive by design (the deployment contract sets
  the names verbatim) and ASCII-only (name bytes == UTF-16 units).
- Rewired call sites: `config.rs` (search/replace), `inject.rs`
  (section name/size), `log.rs` (debug toggle + TEMP). The DLL no longer
  imports `GetEnvironmentVariableW` — the linker drops the unused import,
  so even the API-usage hint disappears from the import table.
- Walker safety: name length, value length and whole-block span rails bound
  the scan against corrupted blocks; `=C:=...` per-drive pseudo entries
  (empty name part) are skipped; a malformed entry without `=` bails out.

**Blob hardening.** For embedded blobs of any size:

- `obfb_static!(vis name, b"...")` — ciphertext lives in a static; the
  first call decrypts it IN PLACE at the ciphertext's own address and
  returns the plaintext slice; any further call returns `None` (one-shot:
  a second decode would be misuse/tamper and would corrupt the data). At
  rest the image holds only ciphertext, and no decode-time stack copy of
  the full blob ever exists.
- `blob_decrypt_into(enc, out, params, kb1, kb2)` — streaming chunked
  decode into a caller-owned buffer of any size; the stack never holds
  more than `BLOB_CHUNK` (64) plaintext bytes at once; the chain runs over
  the full site order so the result is exactly the reference decode.
- `wipe` / `wipe16` — volatile zeroization of decoded buffers after use
  (optimizer cannot elide volatile stores).

**Tests.** bs-verify grew from 31 to 39: env-tag validates only the exact
name (bit-flips, truncation, extension, case, avalanche over all positions),
block walk finds the right value among decoys (pseudo entries, `=` in
values, empty values), misses and terminates safely on empty/no-match/
malformed blocks, per-site/per-build tag divergence, macro-vs-runtime
validation, streaming decode equivalence with the reference decoder across
chunk boundaries (0/1/63/64/65/128/129/200), one-shot in-place semantics
(first call Some+correct, second call None), empty blob, wipe zeroization.

Honest limits (unchanged where noted): a runtime emulator or post-decode
memory dump still sees decoded data; for `envname!` the name never exists —
even a full memory dump after config load contains only the VALUES the
process must use anyway.

## v1.2: hardened code-protection engine (src/obf.rs v2)

The string-obfuscation module was rebuilt from scratch. The previous engine
encrypted every literal with one fixed XOR key (`0x3C` / `0x4D7A`); the
ciphertext rode along as decode-loop byte immediates in `.text`. Collecting
those immediates and sweeping 256 keys — a ten-line IDA/r2 script — recovered
every protected string in any build. The new engine:

1. **Per-build master seed** — `build.rs` derives `BACKSTAGE_OBF_SEED` each
   build (deterministic builds still possible: set the env var, same
   convention as `BACKSTAGE_LOADER_SEED`). Identical sources rebuild to
   different ciphertext, key immediates and state tables, killing
   cross-build diffing and build-stable signatures.
2. **Per-call-site keys** — site key = position-salted hash of the literal
   bytes + `line!()`/`column!()`. The same literal at two call sites
   encrypts differently at each.
3. **Per-site parameterized mixer** — the keystream step is a
   SplitMix-style bijection whose additive constant, two multipliers and
   three shift amounts are random per site. There are **zero universal magic
   constants in the shipped image** — every immediate in a decode loop is
   per-site random, so constant-anchored signatures have no anchor.
4. **Split-key immediates** — the feedback-chain seed ships as two XOR
   shares recombined through `core::hint::black_box`; no single immediate
   holds key material.
5. **Feedback chain** — each decoded byte is mixed back into the running
   state: patching one ciphertext byte corrupts that byte and everything
   decoded after it (integrity by avalanche, no checksum needed).
6. **Randomized decode shape** — per-byte transform `rol(pt, r) + a ^ k`
   with `r`/`a`/`k` from per-iteration state, plus a per-site decode
   direction bit (forward/backward). Call sites share no loop-body
   constants.
7. **Opaque runtime decode** — ciphertext and per-iteration state live in
   random-looking statics, read with `read_volatile`; decoded bytes are
   committed with `write_volatile`; state passes through `black_box`. LLVM
   can neither fold plaintext back into `.rodata` nor vectorize the decode.
8. **Length hiding** — the NUL terminator is encrypted with the buffer, so
   string boundaries are not visible in the ciphertext either.
9. **New `obfb!` macro** — same engine for arbitrary embedded byte blobs.

API is drop-in: `obf!` still returns `[u8; len + 1]`, `obf16!` still
returns `[u16; len + 1]`; all call sites compile unchanged.

Honest limits (documented in obf.rs): runtime emulation or a memory dump
after decryption still recovers strings — no compile-time scheme can prevent
that. What fails now: plaintext scans, fixed/repeating-key XOR sweeps,
constant-anchored signatures, shared-decode-loop signatures, cross-build
diffing, and naive ciphertext patching.

## New tests (run in bs-verify harness)

- Roundtrip sweep across 20+ buffer sizes (raw + NUL-terminated), empty and
  single-byte inputs, both decode directions.
- Negative tests: ciphertext is neither plaintext nor recoverable by any of
  the 256 single-byte XOR keys (byte and wide alphabets).
- Per-site divergence (same literal, different call sites) and per-build
  divergence (same literal, different seeds) produce different ciphertext.
- Tamper propagation: one flipped ciphertext byte corrupts the decoded tail.
- State-table structure checks and macro-vs-reference-decoder equivalence.

## Fixes (BINJv1.1 — carried over)

1. Reflective loader: exception table was read from data-directory index 6
   (debug) instead of index 3 (exception). `RtlAddFunctionTable` therefore
   never registered the real `.pdata` — any SEH/C++ exception unwinding
   through the module could crash the host. Now registers the actual
   `.pdata`.
2. Manual-map TLS hazard: build with `panic = "abort"` and no
   `catch_unwind` wrappers, so the image has no live native TLS directory.
3. Hook-enable race: trampoline pointer published before `MH_EnableHook`
   (zero window for the `orig == 0` race on multithreaded targets).
4. Debug-log recursion: re-entrancy guard + sticky open-failure caching.
5. Loader-offset scanner: full NUL-terminated export-name reads (same
   acceptance rule as the agent's Go scanner).
6. Child-inject success mirrors agent semantics: `GetExitCodeThread`, exit
   code 0 = failure, exit code in the log line.
7. Reflective loader hardening: `NtFlushInstructionCache` NULL-guard,
   bounds-checked header/section copies vs `SizeOfImage`.
8. Version stamps: attach/install logs start with `BINJv1.2` (this build).

## Build

```
./scripts/build-backstage-dll.sh          # Linux cross (see script header for env)
scripts\build-backstage-dll.bat           # Windows
BACKSTAGE_LOADER_SEED=1234 BACKSTAGE_OBF_SEED=abcd1234 ...   # deterministic build
```

Field markers to look for in `%TEMP%\Overlord\backstage\BackstageInjection-debug-<pid>.log`:
`BINJv1.2 DllMain attach ...` and `BINJv1.2 install: ... loader_export='x######' ...`.
If you still see `BINJv1.1` lines, the old DLL is loaded.

