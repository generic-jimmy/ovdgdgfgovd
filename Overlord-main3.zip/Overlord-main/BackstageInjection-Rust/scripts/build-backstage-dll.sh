#!/usr/bin/env bash
# Build BackstageInjection.x64.dll (x86_64-pc-windows-gnu, statically linked CRT).
#
# Only the GNU target is supported: the reflective loader manually maps the
# image, and the MSVC CRT's TLS/CFG/stack-cookie machinery fast-fails
# (0xC0000409) under a manual map.
#
# Usage:
#   ./scripts/build-backstage-dll.sh                    # random per-build loader export
#   BACKSTAGE_LOADER_SEED=1234 ./scripts/build-backstage-dll.sh
#                                                       # deterministic loader export name
# Optional cross toolchain (when not building on Windows):
#   CC_x86_64_pc_windows_gnu=x86_64-w64-mingw32-clang \
#   AR_x86_64_pc_windows_gnu=x86_64-w64-mingw32-ar \
#   CARGO_TARGET_X86_64_PC_WINDOWS_GNU_LINKER=x86_64-w64-mingw32-clang \
#   ./scripts/build-backstage-dll.sh
set -euo pipefail
cd "$(dirname "$0")/.."

command -v cargo >/dev/null 2>&1 || { echo "cargo not found in PATH" >&2; exit 1; }
rustup target add x86_64-pc-windows-gnu >/dev/null 2>&1 || true

cargo build --release --target x86_64-pc-windows-gnu

OUT="target/x86_64-pc-windows-gnu/release/BackstageInjection.dll"
test -f "$OUT" || { echo "expected artifact missing: $OUT" >&2; exit 1; }
echo "built: $OUT ($(wc -c < "$OUT") bytes)"
