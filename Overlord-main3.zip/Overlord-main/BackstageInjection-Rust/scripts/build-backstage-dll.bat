@echo off
rem Build BackstageInjection.x64.dll (x86_64-pc-windows-gnu, statically linked CRT).
rem
rem Only the GNU target is supported: the reflective loader manually maps the
rem image, and the MSVC CRT's TLS/CFG/stack-cookie machinery fast-fails
rem (0xC0000409) under a manual map.
rem
rem Usage:
rem   scripts\build-backstage-dll.bat                     random per-build loader export
rem   set BACKSTAGE_LOADER_SEED=1234 && scripts\build-backstage-dll.bat
rem                                                       deterministic loader export name
setlocal
cd /d "%~dp0.."

where cargo >nul 2>nul || (echo cargo not found in PATH & exit /b 1)
rustup target add x86_64-pc-windows-gnu

cargo build --release --target x86_64-pc-windows-gnu
if errorlevel 1 exit /b 1

set "OUT=target\x86_64-pc-windows-gnu\release\BackstageInjection.dll"
if not exist "%OUT%" (echo expected artifact missing: %OUT% & exit /b 1)
echo built: %OUT%
endlocal
