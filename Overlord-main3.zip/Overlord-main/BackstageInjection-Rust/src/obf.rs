//! Build-time code & data protection engine (v3).
//!
//! `obf!`, `obf16!` and `obfb!` encrypt literal data at compile time so no
//! plaintext — not even under a fixed-key XOR sweep — exists in the binary's
//! read-only data. The runtime expansion reconstructs the data into a fresh
//! stack buffer at each call site. On top of the literal engine, v3 adds
//! `envname!` — config/env names that are never materialized anywhere, but
//! matched as per-site double hashes against the process environment block —
//! and the blob-hardening layer (`obfb_static!`, `blob_decrypt_into`,
//! `wipe`).
//!
//! # Why the old engine (v1) was weak
//!
//! v1 XORed every literal with one fixed byte/word (`0x3C` / `0x4D7A`).
//! One `strings`-style pass over all 256 single-byte keys recovered every
//! protected string in the binary, and the constant key anchored a universal
//! signature across builds.
//!
//! # What v2 does
//!
//! 1. **Per-build master seed.** `build.rs` derives a 64-bit seed each build
//!    (`BACKSTAGE_OBF_SEED`) and injects it as a compile-time env. Two builds
//!    of identical sources produce different ciphertext, different key
//!    immediates and different state tables — cross-build diffing and
//!    build-stable signatures are dead.
//!
//! 2. **Per-call-site keys.** The site key is a salted hash of the literal
//!    bytes *and* the invocation `line!()`/`column!()`. The same literal used
//!    at two call sites encrypts differently at each.
//!
//! 3. **Per-site parameterized mixer.** The keystream step is a SplitMix-style
//!    bijection whose additive constant, two multipliers and three shift
//!    amounts are all derived per site. There is **no universal magic
//!    constant anywhere in the shipped image** — every immediate in the decode
//!    path is random per site and per build, so constant-anchored signatures
//!    have nothing to anchor on.
//!
//! 4. **Split-key immediates.** The feedback-chain seed is XOR-split into two
//!    shares recombined through `core::hint::black_box`, so no single
//!    immediate holds key material and LLVM cannot fold the chain.
//!
//! 5. **Feedback chain (tamper propagation).** Each decoded byte is mixed
//!    back into the running state, so patching one ciphertext byte corrupts
//!    the decoded value *and* every byte decoded after it in site order —
//!    integrity by avalanche, no checksum needed.
//!
//! 6. **Randomized decode shape.** The per-byte transform is
//!    `pt -> rol(pt, r) + a ^ k` with `r`/`a`/`k` taken from per-iteration
//!    state, and the decode *direction* (forward/backward) is a per-site
//!    bit. Call sites share no loop-body constants.
//!
//! 7. **Opaque runtime decode.** Ciphertext and per-iteration state live in
//!    random-looking statics read with `read_volatile`; every decoded byte is
//!    committed with `write_volatile`; the chain and effective state pass
//!    through `black_box`. LLVM can neither fold the plaintext back into
//!    `.rodata` nor vectorize/elide the decode.
//!
//! 8. **Length hiding.** For `obf!`/`obf16!` the NUL terminator is encrypted
//!    with the rest of the buffer, so string boundaries are not visible in
//!    the ciphertext either.
//!
//! 9. **Env-name hash matching (`envname!`).** Config/env names go one level
//!    further than encryption: the name is never decrypted at all. The
//!    literal is compiled to two independent per-site hash values and the
//!    runtime locates the value by walking the process environment block and
//!    hash-matching each candidate NAME with the same per-site chains. A
//!    breakpoint on `GetEnvironmentVariableW`, a stack scan during config
//!    load, and every static sweep come up empty — the plaintext name exists
//!    only inside the compiler.
//!
//! 10. **Blob hardening.** `obfb_static!` decrypts a static blob IN PLACE,
//!     exactly once (further calls are refused — a second decode would be
//!     misuse or tamper); `blob_decrypt_into` streams any-size blobs through
//!     a bounded chunk so the stack never holds a full plaintext payload;
//!     `wipe`/`wipe16` volatile-zeroize decoded buffers after use.
//!
//! # Honest limits
//!
//! No compile-time scheme defeats a runtime emulator or a memory dump taken
//! after decryption. What this engine guarantees: static plaintext scans,
//! fixed/repeating-key XOR sweeps, constant-anchored signatures, per-site
//! shared-loop signatures and cross-build binary diffing all fail; each call
//! site must be solved individually against its own randomized constants.
//!
//! For `envname!` the guarantee is stronger — the name never exists — but a
//! guess-and-check dictionary attack remains theoretically possible: an
//! analyst can hash candidate names and compare against a site's two hash
//! constants. A false accept needs BOTH 64-bit chains to agree, and the
//! per-site parameters plus per-build seed keep precomputed tables useless.
//! Note the match is case-sensitive by design (the deployment contract sets
//! exact names) and ASCII-only (names hash byte == UTF-16 unit).
//!
//! # API
//!
//!   - `obf!(b"...")`    -> `[u8; N]`   (N = len + 1, NUL-terminated). For
//!     ANSI strings handed to `GetProcAddress` and friends.
//!   - `obf16!(b"...")`  -> `[u16; N]`  (wide). For module/path names handed
//!     to `GetModuleHandleW`, `CreateFileW`.
//!   - `obfb!(b"...")`   -> `[u8; len]` (raw blob, no NUL). Small embedded
//!     byte data decoded into a stack buffer.
//!   - `envname!(b"...")` -> [`EnvTag`]. Config/env names as per-site
//!     double hashes; pair with `crate::config::read_env_tag` — the name is
//!     never materialized (see item 9).
//!   - `obfb_static!(vis name, b"...")` -> declares `unsafe fn name() ->
//!     Option<&'static [u8]>`, a one-shot in-place decrypt of a static blob.
//!   - `blob_decrypt_into` / `wipe` / `wipe16` — streaming decode into a
//!     caller-owned buffer and post-use zeroization.

/// Per-build master seed, injected by `build.rs` as `BACKSTAGE_OBF_SEED`.
/// The fallback only exists so host-side test harnesses compile without the
/// build script; shipped DLL builds always go through `build.rs`.
pub const MASTER_SEED: u64 = match option_env!("BACKSTAGE_OBF_SEED") {
    Some(hex) => parse_hex64(hex),
    None => 0x5EED_B17A_0000_0001,
};

/// SplitMix64 finalizer — COMPILE-TIME ONLY. Its golden-ratio constants must
/// never appear in runtime code; the runtime mixer is `mix5`, whose constants
/// are per-site immediates derived through this function at compile time.
const fn sm64(x: u64) -> u64 {
    let mut z = x.wrapping_add(0x9E37_79B9_7F4A_7C15);
    z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
    z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
    z ^ (z >> 31)
}

/// Const hex parser for `BACKSTAGE_OBF_SEED` (accepts optional `0x` prefix).
pub const fn parse_hex64(s: &str) -> u64 {
    let b = s.as_bytes();
    let mut i = 0usize;
    if b.len() >= 2 && b[0] == b'0' && (b[1] == b'x' || b[1] == b'X') {
        i = 2;
    }
    let mut acc: u64 = 0;
    while i < b.len() {
        let c = b[i];
        let d = if c >= b'0' && c <= b'9' {
            (c - b'0') as u64
        } else if c >= b'a' && c <= b'f' {
            (c - b'a') as u64 + 10
        } else if c >= b'A' && c <= b'F' {
            (c - b'A') as u64 + 10
        } else {
            break;
        };
        acc = acc.wrapping_mul(16).wrapping_add(d);
        i += 1;
    }
    acc
}

/// Per-call-site key: position-salted FNV-1a over the literal, finished
/// through the compile-time mixer with the build seed. Run only at compile
/// time — none of these constants reach the binary.
pub const fn site_key(seed: u64, lit: &[u8], line: u32, col: u32) -> u64 {
    let mut h: u64 = 0xCBF2_9CE4_8422_2325
        ^ ((line as u64) << 32)
        ^ (col as u64).wrapping_mul(0x9E37_79B9_7F4A_7C15);
    let mut i = 0usize;
    while i < lit.len() {
        h ^= lit[i] as u64;
        h = h.wrapping_mul(0x0000_0100_0000_01B3);
        i += 1;
    }
    sm64(h ^ sm64(seed))
}

/// Everything the decode loop needs, all fields derived per site. Fields used
/// only during const evaluation (`ka`) never appear in the binary; the rest
/// materialize as per-site random immediates.
#[derive(Clone, Copy)]
pub struct SiteParams {
    /// State-table seed (const-eval only).
    pub ka: u64,
    /// Feedback-chain seed, split into two runtime shares.
    pub kb1: u64,
    pub kb2: u64,
    /// Runtime mixer: additive constant, two odd multipliers, three shifts.
    pub gm: u64,
    pub m1: u64,
    pub m2: u64,
    pub sh1: u32,
    pub sh2: u32,
    pub sh3: u32,
    /// Feedback mix multiplier (odd).
    pub fbm: u64,
    /// Decode direction: 0 = forward, 1 = backward.
    pub dir: u8,
}

/// Derive per-site parameters. Compile-time only (sm64 constants stay out of
/// the image; the outputs become immediates).
pub const fn params(key: u64) -> SiteParams {
    let ka = sm64(key ^ 0x0B1F_C0DE_5EED_0001);
    let kb = sm64(key ^ 0x0B1F_C0DE_5EED_0002);
    let kb1 = sm64(key ^ 0x0B1F_C0DE_5EED_0003);
    SiteParams {
        ka,
        kb1,
        kb2: kb ^ kb1,
        gm: sm64(key ^ 0x0B1F_C0DE_5EED_0004),
        m1: sm64(key ^ 0x0B1F_C0DE_5EED_0005) | 1,
        m2: sm64(key ^ 0x0B1F_C0DE_5EED_0006) | 1,
        sh1: 16 + ((sm64(key ^ 0x0B1F_C0DE_5EED_0007) >> 8) as u32 & 31),
        sh2: 16 + ((sm64(key ^ 0x0B1F_C0DE_5EED_0008) >> 16) as u32 & 31),
        sh3: 16 + ((sm64(key ^ 0x0B1F_C0DE_5EED_0009) >> 24) as u32 & 31),
        fbm: sm64(key ^ 0x0B1F_C0DE_5EED_000A) | 1,
        dir: (sm64(key ^ 0x0B1F_C0DE_5EED_000B) >> 63) as u8 & 1,
    }
}

/// Runtime mixer — per-site constants from `SiteParams`. Bijective in `z`
/// (add / xorshift / odd-mul composition), so the chain never collapses.
#[inline(always)]
pub const fn mix5(z: u64, p: SiteParams) -> u64 {
    let mut z = z.wrapping_add(p.gm);
    z = (z ^ (z >> p.sh1)).wrapping_mul(p.m1);
    z = (z ^ (z >> p.sh2)).wrapping_mul(p.m2);
    z ^ (z >> p.sh3)
}

/// Per-iteration state table: random-looking u64s, one per decode step.
/// Compile-time only; ships as an anonymous random-looking data blob.
pub const fn states<const N: usize>(p: SiteParams) -> [u64; N] {
    let mut s = [0u64; N];
    let mut i = 0usize;
    while i < N {
        s[i] = mix5(mix5((i as u64) ^ p.ka, p) ^ p.kb1, p);
        i += 1;
    }
    s
}

// ---------------------------------------------------------------- byte ops

#[inline(always)]
const fn stream_byte(pt: u8, eff: u64) -> u8 {
    let r = ((eff >> 8) & 7) as u32;
    let a = (eff >> 16) as u8;
    let k = eff as u8;
    pt.rotate_left(r).wrapping_add(a) ^ k
}

/// Inverse of [`stream_byte`]. Inlined into every decode loop.
#[inline(always)]
pub const fn unstream_byte(ct: u8, eff: u64) -> u8 {
    let r = ((eff >> 8) & 7) as u32;
    let a = (eff >> 16) as u8;
    let k = eff as u8;
    (ct ^ k).wrapping_sub(a).rotate_right(r)
}

// ---------------------------------------------------------------- wide ops

#[inline(always)]
const fn stream_wide(pt: u16, eff: u64, i: usize) -> u16 {
    let r = ((eff >> 8) & 15) as u32;
    let a = (eff >> 24) as u16;
    let k = (eff >> ((i & 3) << 4)) as u16;
    pt.rotate_left(r).wrapping_add(a) ^ k
}

/// Inverse of [`stream_wide`]. Inlined into every wide decode loop.
#[inline(always)]
pub const fn unstream_wide(ct: u16, eff: u64, i: usize) -> u16 {
    let r = ((eff >> 8) & 15) as u32;
    let a = (eff >> 24) as u16;
    let k = (eff >> ((i & 3) << 4)) as u16;
    (ct ^ k).wrapping_sub(a).rotate_right(r)
}

// ------------------------------------------------------------------ engine

const fn ord_idx(dir: u8, i: usize, n: usize) -> usize {
    if dir & 1 == 0 {
        i
    } else {
        n - 1 - i
    }
}

/// Encrypt `N` bytes (byte alphabet). When `N == src.len() + 1` the trailing
/// slot encrypts a NUL terminator, hiding the string length. Reference
/// implementation used by tests; mirrors the `obf!`/`obfb!` runtime decode.
pub const fn encode<const N: usize>(src: &[u8], p: SiteParams) -> [u8; N] {
    let sp = states::<N>(p);
    let mut chain = p.kb1 ^ p.kb2;
    let mut out = [0u8; N];
    let mut i = 0usize;
    while i < N {
        let idx = ord_idx(p.dir, i, N);
        let pt: u8 = if idx < src.len() { src[idx] } else { 0 };
        out[idx] = stream_byte(pt, sp[i] ^ chain);
        chain = mix5(chain ^ ((pt as u64).wrapping_mul(p.fbm)), p);
        i += 1;
    }
    out
}

/// Reference decoder mirroring the `obf!`/`obfb!` runtime expansion.
#[cfg_attr(not(test), allow(dead_code))]
pub const fn decode_ref<const N: usize>(enc: &[u8; N], p: SiteParams) -> [u8; N] {
    let sp = states::<N>(p);
    let mut chain = p.kb1 ^ p.kb2;
    let mut out = [0u8; N];
    let mut i = 0usize;
    while i < N {
        let idx = ord_idx(p.dir, i, N);
        let d = unstream_byte(enc[idx], sp[i] ^ chain);
        out[idx] = d;
        chain = mix5(chain ^ ((d as u64).wrapping_mul(p.fbm)), p);
        i += 1;
    }
    out
}

/// Wide alphabet variant of [`encode`] (`obf16!`): `N = src.len() + 1` u16
/// slots, the last one encrypting the wide NUL.
pub const fn encode16<const N: usize>(src: &[u8], p: SiteParams) -> [u16; N] {
    let sp = states::<N>(p);
    let mut chain = p.kb1 ^ p.kb2;
    let mut out = [0u16; N];
    let mut i = 0usize;
    while i < N {
        let idx = ord_idx(p.dir, i, N);
        let pt: u16 = if idx < src.len() { src[idx] as u16 } else { 0 };
        out[idx] = stream_wide(pt, sp[i] ^ chain, i);
        chain = mix5(chain ^ ((pt as u64).wrapping_mul(p.fbm)), p);
        i += 1;
    }
    out
}

/// Reference decoder mirroring the `obf16!` runtime expansion.
#[cfg_attr(not(test), allow(dead_code))]
pub const fn decode_ref16<const N: usize>(enc: &[u16; N], p: SiteParams) -> [u16; N] {
    let sp = states::<N>(p);
    let mut chain = p.kb1 ^ p.kb2;
    let mut out = [0u16; N];
    let mut i = 0usize;
    while i < N {
        let idx = ord_idx(p.dir, i, N);
        let d = unstream_wide(enc[idx], sp[i] ^ chain, i);
        out[idx] = d;
        chain = mix5(chain ^ ((d as u64).wrapping_mul(p.fbm)), p);
        i += 1;
    }
    out
}

// ------------------------------------------------------------------ macros

/// ANSI string literal -> `[u8; len + 1]`, NUL-terminated, decrypted at the
/// call site into a stack buffer. See the [module docs](self) for the engine.
#[macro_export]
macro_rules! obf {
    ($lit:literal) => {{
        const SRC: &[u8] = $lit;
        const LEN: usize = SRC.len() + 1;
        const KEY: u64 =
            $crate::obf::site_key($crate::obf::MASTER_SEED, SRC, line!(), column!());
        const P: $crate::obf::SiteParams = $crate::obf::params(KEY);
        static SP: [u64; LEN] = $crate::obf::states::<LEN>(P);
        static ENC: [u8; LEN] = $crate::obf::encode::<LEN>(SRC, P);
        let mut buf = [0u8; LEN];
        let mut chain = core::hint::black_box(P.kb1) ^ core::hint::black_box(P.kb2);
        let mut i = 0usize;
        while i < LEN {
            let idx = if P.dir & 1 == 0 { i } else { LEN.wrapping_sub(i).wrapping_sub(1) };
            let eff = core::hint::black_box(SP[i] ^ chain);
            let d: u8 =
                unsafe { $crate::obf::unstream_byte(core::ptr::read_volatile(&ENC[idx]), eff) };
            unsafe { (buf.as_mut_ptr() as *mut u8).add(idx).write_volatile(d) };
            chain = $crate::obf::mix5(chain ^ ((d as u64).wrapping_mul(P.fbm)), P);
            i += 1;
        }
        buf
    }};
}

/// Wide string literal -> `[u16; len + 1]`, NUL-terminated, decrypted at the
/// call site into a stack buffer. See the [module docs](self) for the engine.
#[macro_export]
macro_rules! obf16 {
    ($lit:literal) => {{
        const SRC: &[u8] = $lit;
        const LEN: usize = SRC.len() + 1;
        const KEY: u64 =
            $crate::obf::site_key($crate::obf::MASTER_SEED, SRC, line!(), column!());
        const P: $crate::obf::SiteParams = $crate::obf::params(KEY);
        static SP: [u64; LEN] = $crate::obf::states::<LEN>(P);
        static ENC: [u16; LEN] = $crate::obf::encode16::<LEN>(SRC, P);
        let mut buf = [0u16; LEN];
        let mut chain = core::hint::black_box(P.kb1) ^ core::hint::black_box(P.kb2);
        let mut i = 0usize;
        while i < LEN {
            let idx = if P.dir & 1 == 0 { i } else { LEN.wrapping_sub(i).wrapping_sub(1) };
            let eff = core::hint::black_box(SP[i] ^ chain);
            let d: u16 = unsafe {
                $crate::obf::unstream_wide(core::ptr::read_volatile(&ENC[idx]), eff, i)
            };
            unsafe { (buf.as_mut_ptr() as *mut u16).add(idx).write_volatile(d) };
            chain = $crate::obf::mix5(chain ^ ((d as u64).wrapping_mul(P.fbm)), P);
            i += 1;
        }
        buf
    }};
}

/// Raw byte blob -> `[u8; len]`, no NUL appended, same engine as [`obf!`].
/// For embedded byte data that is not a C string.
#[macro_export]
macro_rules! obfb {
    ($lit:literal) => {{
        const SRC: &[u8] = $lit;
        const LEN: usize = SRC.len();
        const KEY: u64 =
            $crate::obf::site_key($crate::obf::MASTER_SEED, SRC, line!(), column!());
        const P: $crate::obf::SiteParams = $crate::obf::params(KEY);
        static SP: [u64; LEN] = $crate::obf::states::<LEN>(P);
        static ENC: [u8; LEN] = $crate::obf::encode::<LEN>(SRC, P);
        let mut buf = [0u8; LEN];
        let mut chain = core::hint::black_box(P.kb1) ^ core::hint::black_box(P.kb2);
        let mut i = 0usize;
        while i < LEN {
            let idx = if P.dir & 1 == 0 { i } else { LEN.wrapping_sub(i).wrapping_sub(1) };
            let eff = core::hint::black_box(SP[i] ^ chain);
            let d: u8 =
                unsafe { $crate::obf::unstream_byte(core::ptr::read_volatile(&ENC[idx]), eff) };
            unsafe { (buf.as_mut_ptr() as *mut u8).add(idx).write_volatile(d) };
            chain = $crate::obf::mix5(chain ^ ((d as u64).wrapping_mul(P.fbm)), P);
            i += 1;
        }
        buf
    }};
}

// ------------------------------------------------------ env-name matching
//
// Config/environment names are protected a level beyond `obf16!`: the name is
// NEVER materialized — not as a decode, not on the stack, not at an API
// boundary. `envname!` compiles the name to two independent per-site hash
// values; at runtime the process environment block is walked and every
// candidate NAME is folded with the same per-site chains and compared. The
// Go/agent contract sets the names verbatim, so an exact, case-sensitive
// match is correct by construction.
//
// Preimage hardness: each fold step is `state (op) unit*m` through the
// bijective per-site mixer, so an attacker holding the final h1/h2 and every
// constant in the disassembly can only attack by guessing units backwards
// from the end — charset^n per candidate length — and every guess must
// satisfy BOTH independent chains. Dictionary verification (guess a name,
// check both hashes) remains possible; that is the honest limit, the same
// class as password hashing, and per-site/per-build randomization keeps
// precomputed tables useless.

/// Double hash tag for one environment-variable name, produced by `envname!`.
#[derive(Clone, Copy)]
pub struct EnvTag {
    /// Per-site parameters driving both runtime hash chains.
    pub p: SiteParams,
    /// Chain A final value.
    pub h1: u64,
    /// Chain B final value (different unit-mix composition than A).
    pub h2: u64,
}

/// Compile-time double hash of an env name. ASCII bytes == UTF-16 units for
/// the ASCII names this contract uses. Runtime counterpart: [`hash_wide_name`].
pub const fn env_tag(seed: u64, name: &[u8], line: u32, col: u32) -> EnvTag {
    let key = site_key(seed, name, line, col);
    let p = params(key);
    let mut h1 = p.kb1;
    let mut h2 = p.kb2;
    let mut i = 0usize;
    while i < name.len() {
        let u = name[i] as u64;
        h1 = mix5(h1 ^ u.wrapping_mul(p.m1), p);
        h2 = mix5(h2, p) ^ u.wrapping_mul(p.m2);
        i += 1;
    }
    EnvTag { p, h1, h2 }
}

/// Runtime side of [`env_tag`]: fold `len` wide chars with the tag's chains
/// and compare both. A false accept requires BOTH 64-bit chains to collide.
pub unsafe fn hash_wide_name(name: *const u16, len: usize, t: &EnvTag) -> bool {
    let mut h1 = t.p.kb1;
    let mut h2 = t.p.kb2;
    let mut i = 0usize;
    while i < len {
        let u = *name.add(i) as u64;
        h1 = mix5(h1 ^ u.wrapping_mul(t.p.m1), t.p);
        h2 = mix5(h2, t.p) ^ u.wrapping_mul(t.p.m2);
        i += 1;
    }
    (h1 == t.h1) & (h2 == t.h2)
}

/// Sanity rails for the environment-block walk. Real blocks sit far below
/// both limits; they only stop a corrupted block from causing an unbounded
/// scan through unmapped memory.
const ENV_NAME_MAX_UNITS: usize = 4096;
const ENV_BLOCK_MAX_UNITS: usize = 1 << 20;

/// Walk a NUL-terminated wide environment block (`NAME=VALUE\0` pairs,
/// terminated by an empty entry) and return the value of the name matching
/// the per-site double hash as `(value_ptr, value_len_wchars)`. The caller
/// copies the value out while the block is alive. Entries whose name part is
/// empty (the `=C:=...` per-drive pseudo entries Windows injects) are
/// skipped. Returns `None` when no name matches. Deliberately pure pointer
/// logic so the host harness tests the exact shipped code.
pub unsafe fn env_find_in_block(block: *const u16, t: EnvTag) -> Option<(*const u16, usize)> {
    let start = block;
    let mut cur = block;
    loop {
        // Whole-block span rail (corrupted-block guard, not a real limit).
        if cur.offset_from(start) as usize >= ENV_BLOCK_MAX_UNITS {
            return None;
        }
        if *cur == 0 {
            return None; // terminating empty entry — block end
        }
        // Fold the name part (up to '=').
        let name_start = cur;
        let mut q = cur;
        let mut n = 0usize;
        while *q != 0 && *q != 0x3D {
            q = q.add(1);
            n += 1;
            if n > ENV_NAME_MAX_UNITS {
                return None; // malformed: runaway name
            }
        }
        if *q == 0 {
            return None; // malformed: entry without '='
        }
        if n > 0 && hash_wide_name(name_start, n, &t) {
            let val = q.add(1);
            let mut r = val;
            let mut v = 0usize;
            while *r != 0 {
                r = r.add(1);
                v += 1;
                if v > ENV_BLOCK_MAX_UNITS {
                    return None; // malformed: runaway value
                }
            }
            return Some((val, v));
        }
        // Skip the value and its NUL; advance to the next entry.
        cur = q.add(1);
        let mut v = 0usize;
        while *cur != 0 {
            cur = cur.add(1);
            v += 1;
            if v > ENV_BLOCK_MAX_UNITS {
                return None;
            }
        }
        cur = cur.add(1);
    }
}

/// Env/config variable name -> per-site double-hash [`EnvTag`]. The
/// plaintext name exists ONLY inside the compiler. Pair with
/// `crate::config::read_env_tag` (which walks the environment block via
/// [`env_find_in_block`]) to fetch the value without ever decrypting the
/// name into memory.
#[macro_export]
macro_rules! envname {
    ($lit:literal) => {{
        const SRC: &[u8] = $lit;
        const TAG: $crate::obf::EnvTag =
            $crate::obf::env_tag($crate::obf::MASTER_SEED, SRC, line!(), column!());
        TAG
    }};
}

// --------------------------------------------------------- blob hardening
//
// `obfb!` decodes a blob into one stack array — right for small data, wrong
// for real embedded payloads (stack exhaustion, one contiguous plaintext
// region, no cleanup). The blob layer adds:
//   - `obfb_static!` — ciphertext lives in a static; one call decrypts it
//     IN PLACE and refuses further calls. At rest the image holds only
//     ciphertext; after the one shot the plaintext replaces it at the same
//     address — no decode-time stack copy for a scrape to find.
//   - `blob_decrypt_into` — streaming chunked decode into a caller-owned
//     buffer of any size; the stack never holds more than `BLOB_CHUNK`
//     plaintext bytes at once.
//   - `wipe`/`wipe16` — volatile zeroization of decoded buffers after use.

/// Streaming-decode scratch size: the stack never holds more plaintext than
/// this at any instant.
// Engine API: no in-DLL blob call site yet — shipped ready for embedded
// payloads (see the v1.3 blob-hardening notes in CHANGES.md).
#[allow(dead_code)]
pub const BLOB_CHUNK: usize = 64;

/// Decrypt `enc` (as produced by `encode::<N>` with the same site params and
/// split-seed shares) into `out` in chunks. The chain runs over the full site
/// order, so the result is exactly `decode_ref`. `out` is written per byte
/// with volatile stores; the per-chunk scratch bounds stack exposure.
#[allow(dead_code)] // engine API — see BLOB_CHUNK note
pub fn blob_decrypt_into<const N: usize>(
    enc: &[u8; N],
    out: &mut [u8; N],
    p: SiteParams,
    kb1: u64,
    kb2: u64,
) {
    let sp = states::<N>(p);
    let mut chain = core::hint::black_box(kb1) ^ core::hint::black_box(kb2);
    let mut i = 0usize;
    while i < N {
        let take = (N - i).min(BLOB_CHUNK);
        let mut scratch = [0u8; BLOB_CHUNK];
        let mut j = 0usize;
        while j < take {
            let idx = ord_idx(p.dir, i + j, N);
            let eff = core::hint::black_box(sp[i + j] ^ chain);
            let d = unsafe { unstream_byte(core::ptr::read_volatile(&enc[idx]), eff) };
            scratch[j] = d;
            chain = mix5(chain ^ ((d as u64).wrapping_mul(p.fbm)), p);
            j += 1;
        }
        j = 0;
        while j < take {
            let idx = ord_idx(p.dir, i + j, N);
            unsafe { (out.as_mut_ptr() as *mut u8).add(idx).write_volatile(scratch[j]) };
            j += 1;
        }
        i += take;
    }
}

/// Declare a one-shot in-place encrypted static blob. Expands to a single
/// accessor `unsafe fn $name() -> Option<&'static [u8]>`: the first call
/// decrypts the ciphertext static in place and returns it; any further call
/// returns `None` (a second decode is misuse or tamper — and would corrupt
/// the plaintext into garbage). At rest the image holds only ciphertext;
/// the plaintext exists only after the one shot, at the ciphertext's own
/// address — no copy, no stack copy, nothing extra to scrape from a
/// decode-time stack dump.
#[macro_export]
macro_rules! obfb_static {
    ($vis:vis $name:ident, $lit:literal) => {
        $vis unsafe fn $name() -> Option<&'static [u8]> {
            const SRC: &[u8] = $lit;
            const LEN: usize = SRC.len();
            const KEY: u64 =
                $crate::obf::site_key($crate::obf::MASTER_SEED, SRC, line!(), column!());
            const P: $crate::obf::SiteParams = $crate::obf::params(KEY);
            static SP: [u64; LEN] = $crate::obf::states::<LEN>(P);
            static mut ENC: [u8; LEN] = $crate::obf::encode::<LEN>(SRC, P);
            static FIRED: core::sync::atomic::AtomicBool =
                core::sync::atomic::AtomicBool::new(false);
            if FIRED.swap(true, core::sync::atomic::Ordering::SeqCst) {
                return None;
            }
            unsafe {
                let base = core::ptr::addr_of_mut!(ENC).cast::<u8>();
                let mut chain = core::hint::black_box(P.kb1) ^ core::hint::black_box(P.kb2);
                let mut i = 0usize;
                while i < LEN {
                    let idx = if P.dir & 1 == 0 { i } else { LEN.wrapping_sub(i).wrapping_sub(1) };
                    let eff = core::hint::black_box(SP[i] ^ chain);
                    let d: u8 = $crate::obf::unstream_byte(core::ptr::read_volatile(base.add(idx)), eff);
                    core::ptr::write_volatile(base.add(idx), d);
                    chain = $crate::obf::mix5(chain ^ ((d as u64).wrapping_mul(P.fbm)), P);
                    i += 1;
                }
                Some(&*core::ptr::addr_of!(ENC))
            }
        }
    };
}

/// Volatile zeroization of a decoded plaintext buffer after use. Unlike a
/// plain fill loop, volatile stores cannot be elided by the optimizer.
#[allow(dead_code)] // engine API — see BLOB_CHUNK note
pub fn wipe(buf: &mut [u8]) {
    let p = buf.as_mut_ptr();
    let n = buf.len();
    let mut i = 0usize;
    while i < n {
        unsafe { core::ptr::write_volatile(p.add(i), 0) };
        i += 1;
    }
    core::sync::atomic::fence(core::sync::atomic::Ordering::SeqCst);
}

/// Wide variant of [`wipe`].
#[allow(dead_code)] // engine API — see BLOB_CHUNK note
pub fn wipe16(buf: &mut [u16]) {
    let p = buf.as_mut_ptr();
    let n = buf.len();
    let mut i = 0usize;
    while i < n {
        unsafe { core::ptr::write_volatile(p.add(i), 0) };
        i += 1;
    }
    core::sync::atomic::fence(core::sync::atomic::Ordering::SeqCst);
}

#[cfg(test)]
mod tests {
    use super::{decode_ref, decode_ref16, encode, encode16, params, site_key, states, MASTER_SEED};

    const LIT: &[u8] = b"ntdll.dll";
    const WLIT: &[u8] = b"kernel32.dll";

    #[test]
    fn byte_roundtrip_is_nul_terminated() {
        let s = obf!(b"ntdll.dll");
        assert_eq!(&s[..], b"ntdll.dll\0");
    }

    #[test]
    fn wide_roundtrip_is_nul_terminated() {
        let s = obf16!(b"kernel32.dll");
        let mut expect: Vec<u16> = b"kernel32.dll".iter().map(|&c| c as u16).collect();
        expect.push(0);
        assert_eq!(&s[..], &expect[..]);
    }

    #[test]
    fn blob_roundtrip_exact_bytes() {
        let s = obfb!(b"\x00\x01\xfe\xffrawblob");
        assert_eq!(&s[..], b"\x00\x01\xfe\xffrawblob");
    }

    #[test]
    fn empty_and_single_byte_strings_roundtrip() {
        assert_eq!(&obf!(b"")[..], b"\0");
        assert_eq!(&obf!(b"x")[..], b"x\0");
        assert_eq!(&obfb!(b"")[..], b"");
    }

    #[test]
    fn macro_output_matches_reference_decoder() {
        let p = params(site_key(MASTER_SEED, LIT, line!(), column!()));
        let enc = encode::<10>(LIT, p);
        assert_eq!(decode_ref(&enc, p), *b"ntdll.dll\0");
    }

    #[test]
    fn wide_macro_output_matches_reference_decoder() {
        let p = params(site_key(MASTER_SEED, WLIT, line!(), column!()));
        let enc = encode16::<13>(WLIT, p);
        let mut expect: Vec<u16> = WLIT.iter().map(|&c| c as u16).collect();
        expect.push(0);
        assert_eq!(&decode_ref16(&enc, p)[..], &expect[..]);
    }

    #[test]
    fn ciphertext_is_not_plaintext_nor_single_byte_xor() {
        let p = params(site_key(MASTER_SEED, LIT, line!(), column!()));
        let enc = encode::<10>(LIT, p);
        assert_ne!(&enc[..9], LIT);
        // No single-byte key anywhere turns the ciphertext into the plaintext.
        for k in 0..=255u8 {
            let hit = enc[..9].iter().zip(LIT).all(|(&c, &m)| (c ^ k) == m);
            assert!(!hit, "ciphertext fell to single-byte xor key {k:#04x}");
        }
    }

    #[test]
    fn wide_ciphertext_is_not_plain_nor_single_key_xor() {
        let p = params(site_key(MASTER_SEED, WLIT, line!(), column!()));
        let enc = encode16::<13>(WLIT, p);
        let plain: Vec<u16> = WLIT.iter().map(|&c| c as u16).collect();
        assert_ne!(&enc[..12], &plain[..]);
        for k in 0..=65535u16 {
            let hit = enc[..12].iter().zip(&plain).all(|(&c, &m)| (c ^ k) == m);
            assert!(!hit, "wide ciphertext fell to single-key xor {k:#06x}");
        }
    }

    #[test]
    fn same_literal_different_site_encodes_differently() {
        let p1 = params(site_key(MASTER_SEED, LIT, 100, 8));
        let p2 = params(site_key(MASTER_SEED, LIT, 200, 12));
        assert_ne!(encode::<10>(LIT, p1), encode::<10>(LIT, p2));
        assert_ne!(states::<10>(p1), states::<10>(p2));
    }

    #[test]
    fn same_literal_different_build_seed_encodes_differently() {
        let p1 = params(site_key(0x1111_1111_1111_1111, LIT, 100, 8));
        let p2 = params(site_key(0x2222_2222_2222_2222, LIT, 100, 8));
        assert_ne!(encode::<10>(LIT, p1), encode::<10>(LIT, p2));
    }

    #[test]
    fn both_decode_directions_roundtrip() {
        // Find seeds covering both directions, then verify full roundtrips.
        let mut saw_fwd = false;
        let mut saw_bwd = false;
        for seed in [1u64, 2, 3, 7, 42, 0xdead_beef, u64::MAX, 123456789] {
            let p = params(site_key(seed, LIT, 5, 5));
            let enc = encode::<10>(LIT, p);
            assert_eq!(decode_ref(&enc, p), *b"ntdll.dll\0");
            if p.dir & 1 == 0 {
                saw_fwd = true;
            } else {
                saw_bwd = true;
            }
        }
        assert!(saw_fwd && saw_bwd, "direction sampling missed a side");
    }

    #[test]
    fn roundtrip_sweep_lengths_and_bytes() {
        // Explicit-length sweep (const generics require compile-time N) over a
        // deterministic byte pattern: raw blobs and obf-style NUL-terminated
        // buffers both roundtrip at every size.
        fn rt<const N: usize>(data: &[u8; N]) {
            let p = params(site_key(0xA5A5_5A5A_A5A5_5A5A, data, 9, 9));
            let enc = encode::<N>(data, p);
            assert_eq!(&decode_ref(&enc, p)[..], data);
        }
        fn rt_nul<const N: usize>(data: &[u8]) {
            let p = params(site_key(0xA5A5_5A5A_A5A5_5A5A, data, 9, 9));
            let enc = encode::<N>(data, p); // N = data.len() + 1: last slot encrypts a NUL
            let dec = decode_ref(&enc, p);
            assert_eq!(&dec[..data.len()], data);
            assert_eq!(dec[N - 1], 0, "nul slot");
        }
        macro_rules! pat {
            ($n:expr) => {{
                let mut a = [0u8; $n];
                for (j, b) in a.iter_mut().enumerate() {
                    *b = (j.wrapping_mul(7)).wrapping_add(13) as u8;
                }
                a
            }};
        }
        macro_rules! sweep {
            ($($n:expr),*) => {$({
                let a = pat!($n);
                rt::<$n>(&a);
                if $n > 0 {
                    rt_nul::<{$n + 1}>(&a);
                }
            })*};
        }
        rt::<0>(&[]);
        rt_nul::<1>(b"");
        sweep!(1, 2, 3, 4, 5, 7, 8, 9, 12, 13, 15, 16, 17, 25, 31, 32, 44, 45, 63, 64);
    }

    #[test]
    fn tampering_one_byte_corrupts_the_tail() {
        let p = params(site_key(MASTER_SEED, LIT, 77, 3));
        let mut enc = encode::<10>(LIT, p);
        let clean = decode_ref(&enc, p);
        // Flip a middle byte; everything decoded after it (in site order)
        // must diverge from the clean plaintext.
        let mid = 4;
        enc[mid] ^= 0x40;
        let broken = decode_ref(&enc, p);
        assert_ne!(broken[mid], clean[mid]);
        let later_differ = broken
            .iter()
            .zip(&clean)
            .enumerate()
            .filter(|&(j, _)| j != mid)
            .any(|(_, (&a, &b))| a != b);
        assert!(later_differ, "tamper did not propagate past byte {mid}");
    }

    #[test]
    fn state_table_has_no_trivial_structure() {
        let p = params(site_key(MASTER_SEED, LIT, 12, 34));
        let sp = states::<16>(p);
        // Adjacent entries must not be related by a fixed delta/xor.
        for w in sp.windows(2) {
            assert_ne!(w[0], w[1]);
        }
        assert_ne!(sp[0] ^ sp[1], sp[1] ^ sp[2]);
    }

    #[test]
    fn master_seed_hex_parser() {
        assert_eq!(super::parse_hex64("0123456789abcdef"), 0x0123_4567_89AB_CDEF);
        assert_eq!(super::parse_hex64("0xFF"), 0xFF);
        assert_eq!(super::parse_hex64("ff"), 0xFF);
        assert_eq!(super::parse_hex64(""), 0);
        assert_eq!(super::parse_hex64("zz"), 0);
    }

    #[test]
    fn static_types_are_exact() {
        let _: [u8; 10] = obf!(b"ntdll.dll");
        let _: [u16; 10] = obf16!(b"ntdll.dll");
        let _: [u8; 3] = obfb!(b"abc");
    }

    // ------------------------------------------------ env-name hash matching

    const ENV_NAME: &[u8] = b"RDI_SEARCH_PATH";

    fn to_wide(s: &[u8]) -> Vec<u16> {
        s.iter().map(|&b| b as u16).collect()
    }

    #[test]
    fn env_tag_matches_only_the_exact_name() {
        let tag = super::env_tag(MASTER_SEED, ENV_NAME, 11, 22);
        let wide = to_wide(ENV_NAME);
        assert!(unsafe { super::hash_wide_name(wide.as_ptr(), wide.len(), &tag) });
        // Single-bit flip in one char must fail BOTH chains.
        let mut mutant = wide.clone();
        mutant[4] ^= 1;
        assert!(!unsafe { super::hash_wide_name(mutant.as_ptr(), mutant.len(), &tag) });
        // Truncated, extended and case-changed candidates must all fail.
        assert!(!unsafe { super::hash_wide_name(wide.as_ptr(), wide.len() - 1, &tag) });
        let mut longer = wide.clone();
        longer.push(0x41);
        assert!(!unsafe { super::hash_wide_name(longer.as_ptr(), longer.len(), &tag) });
        let mut lower = wide.clone();
        lower[0] = b'r' as u16;
        assert!(!unsafe { super::hash_wide_name(lower.as_ptr(), lower.len(), &tag) });
        // Every single-char mutation over the full name fails (avalanche).
        for pos in 0..wide.len() {
            let mut m = wide.clone();
            m[pos] ^= 0x20;
            assert!(
                !unsafe { super::hash_wide_name(m.as_ptr(), m.len(), &tag) },
                "mutation at {pos} matched"
            );
        }
    }

    #[test]
    fn env_find_in_block_finds_the_right_value() {
        let tag = super::env_tag(MASTER_SEED, ENV_NAME, 3, 9);
        let mut block: Vec<u16> = Vec::new();
        for entry in [
            "PATH=C:\\Windows",
            "=C:=C:\\current\\dir", // hidden per-drive pseudo entry
            "RDI_SEARCH_PATH=\\??\\C:\\target\\dir",
            "WEIRD=a=b=c", // '=' inside the value
        ] {
            block.extend(entry.encode_utf16());
            block.push(0);
        }
        block.push(0); // terminating empty entry
        let (vptr, vlen) = unsafe { super::env_find_in_block(block.as_ptr(), tag) }.unwrap();
        let val: Vec<u16> = unsafe { core::slice::from_raw_parts(vptr, vlen) }.to_vec();
        assert_eq!(val, to_wide(b"\\??\\C:\\target\\dir"));
    }

    #[test]
    fn env_find_in_block_misses_and_terminates_safely() {
        let tag = super::env_tag(MASTER_SEED, ENV_NAME, 3, 9);
        // Empty block: just the terminator.
        let empty = [0u16; 2];
        assert!(unsafe { super::env_find_in_block(empty.as_ptr(), tag) }.is_none());
        // Well-formed block without the name.
        let mut block = to_wide(b"PATH=C:\\x");
        block.push(0);
        block.extend(to_wide(b"OTHER=y"));
        block.push(0);
        block.push(0);
        assert!(unsafe { super::env_find_in_block(block.as_ptr(), tag) }.is_none());
        // Malformed entry without '=' must bail out bounded, not run away.
        let mut bad = to_wide(b"NODIRENTRY");
        bad.push(0);
        bad.push(0);
        assert!(unsafe { super::env_find_in_block(bad.as_ptr(), tag) }.is_none());
    }

    #[test]
    fn env_find_handles_empty_value_and_equals_in_value() {
        let tag = super::env_tag(MASTER_SEED, b"EMPTY", 7, 7);
        let mut block: Vec<u16> = Vec::new();
        for entry in ["EMPTY=", "AFTER=1"] {
            block.extend(entry.encode_utf16());
            block.push(0);
        }
        block.push(0);
        let (vptr, vlen) = unsafe { super::env_find_in_block(block.as_ptr(), tag) }.unwrap();
        assert_eq!(vlen, 0);
        assert_eq!(unsafe { *vptr }, 0);
    }

    #[test]
    fn env_tag_differs_per_site_and_build() {
        let a = super::env_tag(MASTER_SEED, ENV_NAME, 10, 5);
        let b = super::env_tag(MASTER_SEED, ENV_NAME, 20, 5);
        assert_ne!(a.h1, b.h1);
        assert_ne!(a.h2, b.h2);
        let c = super::env_tag(0x1234_5678_9ABC_DEF0, ENV_NAME, 10, 5);
        assert_ne!(a.h1, c.h1);
        assert_ne!(a.h2, c.h2);
        // The two chains are independent: same input never yields h1 == h2.
        assert_ne!(a.h1, a.h2);
    }

    #[test]
    fn envname_macro_compiles_and_validates_its_name() {
        let t = crate::envname!(b"RDI_DLL_SECTION");
        let wide = to_wide(b"RDI_DLL_SECTION");
        // The macro-produced tag must validate the exact runtime name...
        assert!(unsafe { super::hash_wide_name(wide.as_ptr(), wide.len(), &t) });
        // ...and reject a near-miss.
        assert!(!unsafe { super::hash_wide_name(wide.as_ptr(), wide.len() - 1, &t) });
    }

    // -------------------------------------------------------- blob hardening

    #[test]
    fn blob_streaming_decode_matches_reference_across_chunk_boundaries() {
        macro_rules! case {
            ($n:expr, $seed:expr) => {{
                let mut data = [0u8; $n];
                for (k, b) in data.iter_mut().enumerate() {
                    *b = (k.wrapping_mul(31)).wrapping_add(7) as u8;
                }
                let key = super::site_key($seed, &data, 5, 5);
                let p = super::params(key);
                let enc = encode::<$n>(&data, p);
                let mut out = [0u8; $n];
                super::blob_decrypt_into(&enc, &mut out, p, p.kb1, p.kb2);
                assert_eq!(out, super::decode_ref(&enc, p), "n={} vs reference", $n);
                assert_eq!(out, data, "n={} roundtrip", $n);
            }};
        }
        case!(0, 1u64);
        case!(1, 1u64);
        case!(63, 1u64); // BLOB_CHUNK - 1
        case!(64, 1u64); // == BLOB_CHUNK
        case!(65, 1u64); // BLOB_CHUNK + 1
        case!(128, 1u64); // 2 chunks
        case!(129, 0xdead_beefu64);
        case!(200, 0xdead_beefu64);
    }

    #[test]
    fn obfb_static_one_shot_in_place() {
        obfb_static!(get_blob, b"\x01\x02\x03PAYLOAD\x00\xff");
        let first = unsafe { get_blob() };
        assert_eq!(first.unwrap(), b"\x01\x02\x03PAYLOAD\x00\xff");
        // One-shot: the second call is refused instead of corrupting.
        assert!(unsafe { get_blob() }.is_none());
    }

    #[test]
    fn obfb_static_empty_blob_roundtrips() {
        obfb_static!(get_empty, b"");
        let v = unsafe { get_empty() };
        assert!(v.is_some());
        assert_eq!(v.unwrap().len(), 0);
    }

    #[test]
    fn wipe_zeroizes_volatile() {
        let mut a = [7u8; 33];
        super::wipe(&mut a);
        assert!(a.iter().all(|&b| b == 0));
        let mut w = to_wide(b"secretvalue");
        super::wipe16(&mut w);
        assert!(w.iter().all(|&c| c == 0));
    }
}
