//! Redirect configuration read from the process environment on attach.
//!
//! Env var NAMES are protected one level beyond encryption: `envname!`
//! compiles each name to a per-site double hash ([`crate::obf::EnvTag`]) and
//! the value is located by walking the environment block and hash-matching
//! candidate names at runtime ([`crate::obf::env_find_in_block`]). The
//! plaintext name is never decrypted into memory — not in the image, not on
//! the stack, not in registers at an API boundary. `GetEnvironmentVariableW`
//! is no longer called at all, so a breakpoint or API-hook watch on it
//! reveals nothing about this DLL's configuration contract. Values themselves
//! are runtime data supplied by the agent and are copied out normally.

use crate::abi;
use crate::obf::EnvTag;
use crate::envname;

/// Parity with the former fixed-buffer reads: values longer than this are
/// treated as absent. No real config value (NT-prefixed paths, section
/// names, decimal sizes) approaches the limit.
const ENV_VALUE_MAX_WCHARS: usize = 2048;

#[derive(Default, Clone)]
pub struct HookConfig {
    pub search: Vec<u16>,
    pub replace: Vec<u16>,
}

pub fn load() -> HookConfig {
    HookConfig {
        search: read_env_tag(envname!(b"RDI_SEARCH_PATH")),
        replace: read_env_tag(envname!(b"RDI_REPLACE_PATH")),
    }
}

/// Locate the value for a hashed env name by enumerating the process
/// environment block. The name is compared only as a per-site double hash —
/// it is never materialized. Returns the value without NUL, or an empty Vec
/// when the name is absent (or the value exceeds [`ENV_VALUE_MAX_WCHARS`]).
pub fn read_env_tag(tag: EnvTag) -> Vec<u16> {
    unsafe {
        let block = abi::GetEnvironmentStringsW();
        if block.is_null() {
            return Vec::new();
        }
        let value = crate::obf::env_find_in_block(block, tag)
            .map(|(ptr, len)| {
                if len >= ENV_VALUE_MAX_WCHARS {
                    Vec::new()
                } else {
                    std::slice::from_raw_parts(ptr, len).to_vec()
                }
            })
            .unwrap_or_default();
        abi::FreeEnvironmentStringsW(block);
        value
    }
}
