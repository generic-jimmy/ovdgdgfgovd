const form = document.getElementById("login-form");
const user = document.getElementById("user");
const pass = document.getElementById("pass");
const mfaGroup = document.getElementById("mfa-group");
const mfaCode = document.getElementById("mfa-code");
const errEl = document.getElementById("error");
const oidcLogin = document.getElementById("oidc-login");
const oidcLoginLabel = document.getElementById("oidc-login-label");
const loginBrand = document.getElementById("login-brand");
const loginTitle = document.getElementById("login-title");
const loginSubtitle = document.getElementById("login-subtitle");
const loginIcon = document.getElementById("login-icon");
const loginLogo = document.getElementById("login-logo");
const loginHeroImage = document.getElementById("login-hero-image");
const loginBrandFooter = document.getElementById("login-brand-footer");
const loginSupportLink = document.getElementById("login-support-link");

(() => {
  const params = new URLSearchParams(window.location.search);
  const oidcError = params.get("oidc_error");
  if (oidcError) {
    errEl.textContent = oidcError;
    window.history.replaceState({}, document.title, "/login.html");
  }
})();

(async () => {
  try {
    const res = await fetch("/api/login/branding");
    if (!res.ok) return;
    const data = await res.json();

    if (loginBrand && data.productName) loginBrand.textContent = data.productName;
    if (loginTitle && data.title) loginTitle.textContent = data.title;
    if (loginSubtitle && data.subtitle) loginSubtitle.textContent = data.subtitle;
    document.title = data.tabName || (data.productName ? `${data.productName} — Sign in` : document.title);
    if (data.faviconUrl) {
      let favicon = document.querySelector('link[rel~="icon"]');
      if (!favicon) {
        favicon = document.createElement("link");
        favicon.rel = "icon";
        document.head.appendChild(favicon);
      }
      favicon.href = data.faviconUrl;
    }

    if (loginIcon && data.iconClass) {
      const glyph = loginIcon.querySelector("i") || loginIcon;
      glyph.className = data.iconClass;
    }

    if (loginLogo && loginIcon && data.logoUrl) {
      loginLogo.alt = data.logoAlt || `${data.productName || "Fantasy"} logo`;
      loginLogo.onload = () => {
        loginLogo.style.display = "";
        loginIcon.style.display = "none";
      };
      loginLogo.onerror = () => {
        loginLogo.style.display = "none";
        loginIcon.style.display = "";
      };
      loginLogo.src = data.logoUrl;
    }

    if (loginHeroImage && data.heroImageUrl) {
      loginHeroImage.alt = data.heroImageAlt || "";
      loginHeroImage.onload = () => {
        loginHeroImage.style.display = "";
        document.body.classList.add("login-has-hero-image");
      };
      loginHeroImage.onerror = () => {
        loginHeroImage.style.display = "none";
        document.body.classList.remove("login-has-hero-image");
      };
      loginHeroImage.src = data.heroImageUrl;
    }

    if (loginBrandFooter && data.footerText) {
      loginBrandFooter.textContent = data.footerText;
      loginBrandFooter.style.display = "";
    }

    if (loginSupportLink && data.supportText && data.supportUrl) {
      loginSupportLink.textContent = data.supportText;
      loginSupportLink.href = data.supportUrl;
      if (!data.supportUrl.startsWith("/")) {
        loginSupportLink.target = "_blank";
        loginSupportLink.rel = "noopener noreferrer";
      }
      loginSupportLink.style.display = "";
    }
  } catch {}
})();

(async () => {
  try {
    const res = await fetch("/api/registration/status");
    const data = await res.json();
    if (data.enabled) {
      const el = document.getElementById("register-link");
      if (el) el.style.display = "";
    }
  } catch {}
})();

(async () => {
  try {
    const res = await fetch("/api/oidc/status");
    if (!res.ok) return;
    const data = await res.json();
    if (data.enabled && data.loginUrl && oidcLogin) {
      oidcLogin.href = data.loginUrl;
      if (oidcLoginLabel && data.label) oidcLoginLabel.textContent = data.label;
      oidcLogin.style.display = "";
    }
  } catch {}
})();

form?.addEventListener("submit", async (e) => {
  e.preventDefault();
  errEl.textContent = "";

  const submitBtn = e.target.querySelector('button[type="submit"]');
  const btnText = submitBtn?.querySelector(".btn-text");
  const pending = submitBtn?.dataset.pending === "true";

  if (submitBtn && !pending) {
    submitBtn.dataset.pending = "true";
    submitBtn.disabled = true;
    if (btnText) btnText.textContent = "Signing in…";
  } else if (pending) {
    return;
  }

  try {
    const res = await fetch("/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        user: user.value,
        pass: pass.value,
        mfaCode: mfaCode?.value || "",
      }),
    });

    if (res.status === 202) {
      const data = await res.json().catch(() => ({}));
      if (data.mfaRequired) {
        if (submitBtn) {
          submitBtn.dataset.pending = "false";
          submitBtn.disabled = false;
          if (btnText) btnText.textContent = "Sign in";
        }
        if (mfaGroup) mfaGroup.style.display = "";
        if (mfaCode) {
          mfaCode.required = true;
          mfaCode.focus();
        }
        errEl.textContent = "Enter your authenticator code to continue.";
        return;
      }
    }

    if (!res.ok) {
      const data = await res.json();
      throw new Error(data.error || "Invalid credentials");
    }

    const data = await res.json();

    if (data.user && data.user.mustChangePassword) {
      sessionStorage.setItem("temp_token", data.token);
      sessionStorage.setItem("temp_user", JSON.stringify(data.user));

      window.location.href = "/change-password.html";
    } else {
      window.location.href = "/";
    }
  } catch (err) {
    errEl.textContent = err.message || "Login failed";

    if (submitBtn) {
      submitBtn.dataset.pending = "false";
      submitBtn.disabled = false;
      if (btnText) btnText.textContent = "Sign in";
    }
  }
});
