import { createPasswordPolicyChecklist, loadPasswordPolicy } from "./password-policy.js";

const form = document.getElementById("change-password-form");
const currentPass = document.getElementById("current-pass");
const newPass = document.getElementById("new-pass");
const confirmPass = document.getElementById("confirm-pass");
const errEl = document.getElementById("error");
const successEl = document.getElementById("success");
const policyEl = document.getElementById("password-policy");

const tempToken = sessionStorage.getItem("temp_token");
const tempUser = sessionStorage.getItem("temp_user");

if (!tempToken || !tempUser) {
  window.location.href = "/";
}

const user = JSON.parse(tempUser);

const passwordChecklist = createPasswordPolicyChecklist({
  passwordInput: newPass,
  confirmInput: confirmPass,
  container: policyEl,
});

loadPasswordPolicy().then((policy) => passwordChecklist.setPolicy(policy));

form?.addEventListener("submit", async (e) => {
  e.preventDefault();
  errEl.textContent = "";
  successEl.textContent = "";

  if (newPass.value !== confirmPass.value) {
    errEl.textContent = "New passwords do not match";
    return;
  }

  const policyError = passwordChecklist.firstError();
  if (policyError) {
    errEl.textContent = policyError;
    return;
  }


  try {
    const res = await fetch(`/api/users/${user.id}/password`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${tempToken}`,
      },
      body: JSON.stringify({
        currentPassword: currentPass.value,
        newPassword: newPass.value,
      }),
    });

    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.error || "Failed to change password");
    }

    sessionStorage.removeItem("temp_token");
    sessionStorage.removeItem("temp_user");

    successEl.textContent = "Password changed successfully! Redirecting...";

    setTimeout(() => {
      window.location.href = "/";
    }, 2000);
  } catch (err) {
    errEl.textContent = err.message || "Failed to change password";
  }
});
